<HTML>
<HEAD>
<TITLE>Server</TITLE>
</HEAD>

<BODY>

<FONT>

<?php
include "database.inc";

mysqli_close($con);
?>

</BODY>
</HTML>
