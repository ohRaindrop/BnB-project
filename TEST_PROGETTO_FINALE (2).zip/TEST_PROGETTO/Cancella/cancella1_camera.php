<?php
include   "..\database2.inc";

$delete= "DELETE
         FROM Camera 
         WHERE nome='$_POST[nome]'";

if(!mysqli_query($con,$delete))
{
  echo("<br> Errore: ".mysqli_error($con));
  exit();
}
else
 echo ("<br> I dati della camera sono stati cancellati correttamente.");

mysqli_close($con);

?>