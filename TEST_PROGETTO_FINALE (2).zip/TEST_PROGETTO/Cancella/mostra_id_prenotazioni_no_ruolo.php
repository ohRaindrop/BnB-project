<html>
<head>
<link href="myTab.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT Cliente.id_cliente, nome, cognome, data_nascita, tipo_id, identificatore, Prenotazione.id_pren , id_lomb
           FROM Cliente, Prenotazione, Effettua
           WHERE Cliente.id_cliente in
                 (SELECT DISTINCT id_cliente
                  FROM Effettua
                  WHERE cliente.id_cliente=Effettua.id_cliente and Prenotazione.id_pren=Effettua.id_pren) 
           GROUP BY id_lomb";


$result=mysqli_query($con,$select);
if (empty($result))
{
  echo("<br>Errore: ".mysqli_error($con));
  exit();
}

//creazione array
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);


//verifica di presenza di elementi
if(!$riga)
{
  echo("Nessun elemento che soddisfa i criteri di ricerca � stato trovato. <br><br> Errore: ".mysqli_error($con));
  exit();
}

//mostra dei risultati
echo("<center><h1>Lista dei dati delle prenotazioni:</h1></center>");

echo("<table class='myTab'>");

 echo("<tr>
      <td> Nome </td> <td> Cognome </td> <td> Data di nascita </td> <td> Tipo di identificatore </td><td> Identificatore </td>
      <td> ID della prenotazione </td> <td> ID dato dalla Regione Lombardia </td>
      </tr>");
while($riga)
{
  $data_nascita=new DateTime($riga['data_nascita']);

  echo("<tr>
       <td>$riga[nome]</td>
       <td>$riga[cognome]</td>
         <td>".date_format($data_nascita,'d/m/Y')."</td>
       <td>$riga[tipo_id]</td>
       <td>$riga[identificatore]</td>
       <td>$riga[id_pren]</td>
       <td>$riga[id_lomb]</td>
       </tr>");
  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}

echo("</table><BR><BR><BR>");

mysqli_free_result($result);
mysqli_close($con);
?>