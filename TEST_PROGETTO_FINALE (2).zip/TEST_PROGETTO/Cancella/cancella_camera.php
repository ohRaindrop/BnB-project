<HTML>
<HEAD> </HEAD>

<BODY>

<FONT SIZE=3>

<h3>Elimina i dati di una camera del Bed and Breakfast:</h3>

<FORM ACTION="cancella1_camera.php" METHOD="post"> <br>
Nome della camera: <input type="text" name="nome" maxlength=20> <br>
<br>
<pre>
Nota: eliminando tutti i dati di una camera, perderai anche le informazioni relative alle prenotazioni!         <input type="submit" value="Elimina la camera e tutti i suoi dati">
<br><br>
</pre>
</form>

<?php
include "..\Interrogazioni\mostra_nome_camere.php";
?>

</body>
</html>
