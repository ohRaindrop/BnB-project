<html>
<head>
<link href="myTab.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= "SELECT nome
          FROM Camera";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ((!$result) OR (!$riga))
{
  echo("<br>Errore: Non esistono camere. ".mysqli_error($con));
  exit();
}


//mostra dei risultati

echo("<center><h1>Lista delle camere:</h1></center>");

echo("<table class='myTab'>");

 echo("<tr>
      <td> Nome </td>
      </tr>");
while($riga)
{
  echo("<tr>
       <td>$riga[nome]</td>
       </tr>");

  $riga=mysqli_fetch_array($result, MYSQLI_ASSOC);
}

echo("</table>");
mysqli_free_result($result);
mysqli_close($con);
?>