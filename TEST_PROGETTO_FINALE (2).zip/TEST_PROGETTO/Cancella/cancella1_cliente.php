<?php
include   "..\database2.inc";

$delete= "DELETE
          FROM Cliente
          WHERE identificatore='$_POST[identificatore]';";

if(!mysqli_query($con,$delete))
{
  echo("<br> Errore: ".mysqli_error($con));
  exit();
}
else
 echo ("<br> I dati del cliente sono stati cancellati correttamente.");

mysqli_close($con);

?>