<html>
<head>
<link href="myTab.css" rel="stylesheet" type="text/css">
</head>
<body>


<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT Cliente.nome AS nome_cliente,cognome, check_out, check_in, num_letti, nome_camera, ruolo
           FROM Cliente
                INNER JOIN Effettua
                      ON Cliente.id_cliente=Effettua.id_cliente
                INNER JOIN Prenotazione
                      ON Effettua.id_pren=Prenotazione.id_pren
                INNER JOIN Relativa
                      ON Prenotazione.id_pren=Relativa.id_pren
                INNER JOIN Camera
                      ON Relativa.nome_camera=Camera.nome
           WHERE (ruolo='capogruppo' OR ruolo='ospite singolo' OR ruolo='capofamiglia')
          ";


$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ((!$result) OR (!$riga))
{
  echo("<br>Errore: Nessun elemento che soddisfa i criteri di ricerca trovato.".mysqli_error($result));
  exit();
}


//mostra dei risultati
echo("<center><h1>Lista dei dati delle prenotazioni e delle camere:</h1></center>");

echo("<table class='myTab'>");

 echo("<tr>
      <td> Nome </td> <td> Cognome </td> <td> Ruolo </td> <td> Numero totale di presone </td> <td> Camera </td> <td> Check-in </td> <td> Check-out </td>
      </tr>");
while($riga)
{
  $num_letti=$riga[adulti_matrimoniale]+$riga[bimbi_0_3]+$riga[bimbi_3_10]+$riga[ragazzi]+$riga[altri_adulti];
  echo("<tr>
       <td>$riga[nome_cliente]</td>
       <td>$riga[cognome]</td>
       <td>$riga[ruolo]</td>
       <td>$num_letti</td>
       <td>$riga[nome_camera]</td>
       <td>$riga[data_arrivo]</td>
       <td>$riga[data_partenza]</td>
       </tr>");
  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}

echo("</table>");

mysqli_free_result($result);
mysqli_close($con);
?>