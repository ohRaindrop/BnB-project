<?php
include   "..\database2.inc";

$delete= "DELETE
         FROM Pagamento
         WHERE num_pagamento='$_POST[num_pagamento]'";

if(!mysqli_query($con,$delete))
{
  echo("<br> Errore: ".mysqli_error($con));
  exit();
}
else
 echo ("<br> I dati del pagamento sono stati cancellati correttamente.");

mysqli_close($con);

?>