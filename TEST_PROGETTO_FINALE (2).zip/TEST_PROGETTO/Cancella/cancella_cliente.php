<HTML>
<HEAD> </HEAD>

<BODY>
<FONT SIZE=3>

<h3>Elimina i dati del Cliente:</h3>

<FORM ACTION="cancella1_cliente.php" METHOD="post"> <br>
Identificatore: <input type="text" name="identificatore"> <br>
<br>
<input type="submit" value="Elimina il cliente e tutti i suoi dati">
<br> <br>

</form>
<u> <b> NOTA! </b> </u> <br>
Cancellando un cliente, eliminerai anche tutti i dati a lui legati, inclusi i dati dei pagamenti e delle prenotazioni!
<br>

<?php
include "..\Interrogazioni\mostra_clienti.php";
?>

</body>
</html>