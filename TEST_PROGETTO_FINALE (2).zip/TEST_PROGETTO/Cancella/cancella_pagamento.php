<HTML>
<HEAD> </HEAD>

<BODY>
<FONT SIZE=3>

<h3>Elimina permanentemente i dati di un pagamento:</h3>

<FORM ACTION="cancella1_pagamento.php" METHOD="post"> <br>
Numero del pagamento: <input type="number" name="num_pagamento"> <br>
<br>
<input type="submit" value="Elimina il pagamento e tutti i suoi dati">
<br> <br>

</form>

<?php
include "..\Interrogazioni\mostra_pagamenti.php";
?>

</body>
</html>