<?php
include  "..\database2.inc";

// operazione sul database e verifica di successo
$select= "SELECT * FROM Cliente WHERE id_cliente='$_POST[id_cliente]'";
$ris=mysqli_query($con,$select);

if(!$ris)
{
  echo("Errore: ".mysqli_error($con));
  exit();
}

$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if(!$riga)
 {
   echo("Cliente non presente nel database.<br>");
   echo("<a href='modifica_cliente.php'> Riprova </a>");
   exit();
 }

//Imposizione della data massima
$max = new DateTime();

//Stringhe su cui si fa escape
$luogo_nascita_esc=mysqli_real_escape_string ($con , "$riga[luogo_nascita]" );
$indirizzo_esc=mysqli_real_escape_string ($con , "$riga[indirizzo]" );
$luogo_rilascio_esc=mysqli_real_escape_string ($con , "$riga[luogo_rilascio]" );
$nome_esc=mysqli_real_escape_string ($con , "$riga[nome]" );
$cognome_esc=mysqli_real_escape_string ($con , "$riga[cognome]" );
$tipo_id_esc=mysqli_real_escape_string ($con , "$riga[tipo_id]" );
$tipo_doc_ric_esc=mysqli_real_escape_string ($con , "$riga[tipo_doc_ric]" );



//prima modifica
echo("<form action=modifica2_cliente.php method=post>
<pre>

Id cliente: <INPUT TYPE=number NAME=id_cliente value=$riga[id_cliente] readonly> <br><br><br>
<fieldset> <legend> <b> DATI ANAGRAFICI </b> </legend>
Nome*:  <INPUT TYPE=text NAME=nome value='$nome_esc' maxlength='30' required>   Cognome*:  <INPUT TYPE=text NAME=cognome value='$cognome_esc' maxlength=30 required>   Sesso*:  <select name='sesso' required>
                                                                                                                                  <option value='Uomo'>Uomo</option>
                                                                                                                                  <option value='Donna'>Donna</option>
                                                                                                                                  </select>
Luogo di nascita*:  <INPUT TYPE=text NAME=luogo_nascita value='$luogo_nascita_esc' required>   Data di nascita*:  <INPUT TYPE=date NAME=data_nascita value='$riga[data_nascita]' required><BR>
Tipo di identificatore*: <select name='tipo_id' required>
                        <option value='Codice fiscale'>Codice fiscale</option>
                        <option value='Partita IVA'>Partita IVA</option>
                        <option value='Altro'>Altro</option>
                        </select> Identificatore*: <INPUT TYPE='text' NAME='identificatore' value='$riga[identificatore]' title='Inserire una stringa identificativa' required>

</fieldset> <br>
<fieldset> <legend> <b> RECAPITI </b> </legend>
Indirizzo:  <INPUT TYPE=text NAME=indirizzo maxlength=100 value=$indirizzo_esc>   Indirizzo email:  <INPUT TYPE=email NAME=mail value='$riga[mail]' maxlength='50' title='nel formato: user@dominio.it'>   Telefono*:  <INPUT TYPE=tel NAME=telefono value='$riga[telefono]' maxlength='10' title='Nota: non inserire il +39!!'>

</fieldset> <br>
<fieldset> <legend> <b> CITTADINANZA E DOCUMENTO DI RICONOSCIMENTO </b> </legend>
Cittadinanza:      <INPUT TYPE=text NAME=cittadinanza value='$riga[cittadinanza]' required><BR>
Documento di riconoscimento: <br>
          Tipo:  <select name='tipo_doc_ric' value='$tipo_doc_ric_esc'>
                 <option value='carta_identita'>Carta d'identit�</option>
                 <option value='patente'>Patente</option>
                 <option value='passaporto'>Passaporto</option>
                 <option value='permesso di soggiorno'> Permesso di soggiorno </option>
                 </select>   Numero:   <INPUT TYPE=text NAME=numero_doc_ric value='$riga[numero_doc_ric]' maxlength='20' required>
          Luogo di rilascio:  <INPUT TYPE=text NAME=luogo_rilascio value='$luogo_rilascio_esc' maxlength='50'>   Data di rilascio:  <INPUT TYPE=date NAME=data_rilascio value='$riga[data_rilascio]'>
</fieldset>
</pre>
<input type=submit value=Conferma><br>");

mysqli_free_result($ris);
mysqli_close($con);

?>