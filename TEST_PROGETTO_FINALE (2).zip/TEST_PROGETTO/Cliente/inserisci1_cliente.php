<?php

include   "..\database2.inc";

//Stringhe escape
$luogo_nascita_esc=mysqli_real_escape_string ($con , "$_POST[luogo_nascita]" );
$indirizzo_esc=mysqli_real_escape_string ($con , "$_POST[indirizzo]" );
$luogo_rilascio_esc=mysqli_real_escape_string ($con , "$_POST[luogo_rilascio]" );
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]" );
$cognome_esc=mysqli_real_escape_string ($con , "$_POST[cognome]" );
$tipo_id_esc=mysqli_real_escape_string ($con , "$_POST[tipo_id]" );
$tipo_doc_ric_esc=mysqli_real_escape_string ($con , "$_POST[tipo_doc_ric]" );



//Inserimento
$insert= "INSERT INTO Cliente (nome, cognome, identificatore, tipo_id, sesso, luogo_nascita, data_nascita, indirizzo, mail, telefono, cittadinanza,
                               tipo_doc_ric, numero_doc_ric,luogo_rilascio, data_rilascio)
         VALUES ('$nome_esc','$cognome_esc','$_POST[identificatore]','$tipo_id_esc','$_POST[sesso]','$luogo_nascita_esc','$_POST[data_nascita]',
                 '$indirizzo_esc','$_POST[mail]','$_POST[telefono]','$_POST[cittadinanza]','$tipo_doc_ric_esc','$_POST[numero_doc_ric]',
                 '$luogo_rilascio_esc','$_POST[data_rilascio]');";
echo("<br>");

$result=mysqli_query($con,$insert);
if (!($result))
{
  echo("<br>Errore: ".mysqli_error($con));
  exit();
}
else
 echo ("<br>Registrazione del cliente effettuata correttamente.");


mysqli_close($con);

?>