<?php
include   "..\database2.inc";

$luogo_nascita_esc=mysqli_real_escape_string ($con , "$_POST[luogo_nascita]" );
$indirizzo_esc=mysqli_real_escape_string ($con , "$_POST[indirizzo]" );
$luogo_rilascio_esc=mysqli_real_escape_string ($con , "$_POST[luogo_rilascio]" );
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]" );
$cognome_esc=mysqli_real_escape_string ($con , "$_POST[cognome]" );
$tipo_id_esc=mysqli_real_escape_string ($con , "$_POST[tipo_id]" );
$tipo_doc_ric_esc=mysqli_real_escape_string ($con , "$_POST[tipo_doc_ric]" );

//attuazione della modifica sul DB
$update="UPDATE Cliente 
         SET nome='$nome_esc', cognome='$cognome_esc', identificatore='$_POST[identificatore]',tipo_id='$tipo_id_esc', sesso='$_POST[sesso]',
             luogo_nascita='$luogo_nascita_esc', data_nascita='$_POST[data_nascita]',indirizzo='$indirizzo_esc',
             mail='$_POST[mail]', telefono='$_POST[telefono]',cittadinanza='$_POST[cittadinanza]',
             tipo_doc_ric='$tipo_doc_ric_esc', numero_doc_ric='$_POST[numero_doc_ric]', luogo_rilascio='$luogo_rilascio_esc',
             data_rilascio='$_POST[data_rilascio]'
         WHERE id_cliente='$_POST[id_cliente]'";

$ris=mysqli_query($con,$update);
if(!$ris)
{
  echo("<br> Errore nel comando UPDATE: " .mysqli_error($con));
  exit();
}

echo("<br> Modifica effettuata correttamente");

mysqli_close($con);

?>