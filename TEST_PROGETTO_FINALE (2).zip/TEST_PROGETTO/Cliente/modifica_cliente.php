<HTML>
<HEAD> </HEAD>

<BODY>
<FONT SIZE=3>

<fieldset> <legend> <b> SCELTA DEL CLIENTE DI RIFERIMENTO </b> </legend>
<FORM ACTION="modifica1_cliente.php" METHOD="POST">
<?php
include "../database2.inc";

//operazione generale su DB e verifica di successo
$select= "SELECT id_cliente, nome,cognome,sesso,luogo_nascita,data_nascita,indirizzo, telefono, identificatore, tipo_id, mail 
          FROM Cliente";


$result=mysqli_query($con,$select);

if ((empty($result)))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca ".mysqli_error($con));
  exit();
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }
 if ((empty($rows)))
 {
   echo ("Non ci sono clienti da modificare.");
   exit();
 }


echo (" Scegliere il cliente di cui modificare i dati: <br>");

 foreach($rows as $riga)
 {
     $data_nascita=new DateTime($riga['data_nascita']);

  echo (" <br><input type=radio name=id_cliente value='$riga[id_cliente]'> $riga[cognome] $riga[nome] - $riga[sesso] <br>
         &emsp; &emsp; &emsp; &emsp; &emsp; Nato a  $riga[luogo_nascita] il ".date_format($data_nascita,'d/m/Y')."  <br>
         &emsp; &emsp; &emsp; &emsp; &emsp; $riga[tipo_id] : $riga[identificatore] <br>");
 }

}

?>
<br><br><br>
<input type="submit" value="Continua per modificare i dati del cliente">
</FORM>
</fieldset>

</BODY>
</HTML>