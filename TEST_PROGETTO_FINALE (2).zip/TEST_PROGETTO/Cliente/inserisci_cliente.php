<HTML>

<HEAD>
<script>
function myID()
{
        var nome = (document.getElementById("nome").value).substring(0,3);
        var cognome = (document.getElementById("cognome").value).substring(0,3);
        var data = new Date(document.getElementById("data_nascita").value).getFullYear().toString();
        var luogo = (document.getElementById("nome").value).substring(0,3);
        var sesso = (document.getElementById("nome").value).substring(0,3);
        document.getElementById("CF").innerHTML = nome.toUpperCase() + cognome.toUpperCase() + data.substring(2,4);
}
</script>
</HEAD>

<BODY>
<FONT SIZE=3>

<?php $max = new DateTime(); ?>

<FORM ACTION="inserisci1_cliente.php" METHOD="post">
<pre>
<fieldset> <legend> <b> DATI ANAGRAFICI </b> </legend>
Nome*:  <INPUT TYPE="text" NAME="nome" maxlength="30" id="nome" required >   Cognome*:  <INPUT TYPE="text" NAME="cognome" maxlength="30" id="cognome" required>   Sesso*:  <select name='sesso' required>
                                                                                                                                                                           <option value='Uomo'>Uomo</option>
                                                                                                                                                                           <option value='Donna'>Donna</option>
                                                                                                                                                                           </select>
Luogo di nascita*:  <INPUT TYPE="text" NAME="luogo_nascita" id="luogo_nascita" maxlength="50" required>   Data di nascita*:  <INPUT TYPE="date" NAME="data_nascita" id="data_nascita" max=<?=$max->format("Y-m-d")?> required><BR>

Tipo di identificatore*: <select name="tipo_id" required>
                        <option value="Codice fiscale">Codice fiscale</option>
                        <option value="Partita IVA">Partita IVA</option>
                        <option value="Altro">Altro</option>
                        </select> Identificatore*: <INPUT TYPE="text" NAME="identificatore" id="identificatore" maxlength="20" required>
</fieldset>

<fieldset> <legend> <b> RECAPITI </b> </legend>
Indirizzo:  <INPUT TYPE="text" NAME="indirizzo" maxlength="100">   Indirizzo email:  <INPUT TYPE="email" NAME="mail" maxlength="50" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="nel formato user@dominio.it">   Telefono:  <INPUT TYPE="tel" NAME="telefono" maxlength="10" title="Non inserire il +39">


</fieldset>

<fieldset> <legend> <b> CITTADINANZA E DOCUMENTO DI RICONOSCIMENTO </b> </legend>
Cittadinanza:  <INPUT TYPE="text" NAME="cittadinanza"><BR>
Documento di riconoscimento:
          Tipo:  <select name='tipo_doc_ric'>
                 <option value='carta di identita'> Carta d'identit� </option>
                 <option value='patente'> Patente </option>
                 <option value='passaporto'> Passaporto </option>
                 <option value='permesso di soggiorno'> Permesso di soggiorno </option>
                 </select>   Numero:  <INPUT TYPE="text" NAME="numero_doc_ric" maxlength="20">

          Luogo di rilascio:  <INPUT TYPE="text" NAME="luogo_rilascio" maxlength="50">   Data di rilascio:  <INPUT TYPE="date" NAME="data_rilascio" max=<?=$max->format("Y-m-d")?>><BR> <BR>
</fieldset>

<u> <b>Nota</b>: i campi contrassegnati da <b>*</b> sono obbligatori.</u>         <input type="submit" value="Aggiungi">

</pre>
</FORM>

</BODY>
</HTML>