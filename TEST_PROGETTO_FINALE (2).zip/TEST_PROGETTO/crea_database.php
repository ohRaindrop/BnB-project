<?php
include "database.inc";

if (mysqli_query($con,"CREATE DATABASE $database"))
  echo ("<BR> Database BB SANTA CRISTINA creato correttamente.");
else
  echo ("<BR> Errore nella creazione del database: ". mysqli_error($con));

mysqli_close($con);
?>