<HTML>
<HEAD> </HEAD>

<BODY>
<FONT SIZE=3>

<fieldset> <legend> <b> SCELTA DELLA CAMERA DI RIFERIMENTO </b> </legend>
<FORM ACTION="modifica1_camera.php" METHOD="POST">
<?php
include "../database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT nome
           FROM camera
           ORDER BY nome";


$result=mysqli_query($con,$select);

if ((empty($result)))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca ".mysqli_error($con));
  exit();
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }
 if ((empty($rows)))
 {
   echo ("Non ci sono camere da modificare.");
   exit();
 }


echo (" Scegliere la camera da modificare: <br>");

 foreach($rows as $riga)
 {
  echo (" <br><input type=radio name=nome value='$riga[nome]'> Camera : <b>$riga[nome]</b> <br>  ");
 }

}

?>
<br><br><br>
<input type="submit" value="Continua per modificare la camera">
</FORM>
</fieldset>

</BODY>
</HTML>