<?php
include  "..\database2.inc";

// operazione sul database e verifica di successo
$select= "SELECT * 
          FROM Camera 
          WHERE nome='$_POST[nome]'";

$ris=mysqli_query($con,$select);
$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if((!$ris) OR (!$riga))
{
  echo("Errore: camere non presenti. ".mysqli_error($con));
  exit();
}


// imposizione della data minima e massima
$max = new DateTime();
$min = new DateTime();

//escape
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]" );


//prima modifica
echo("<form action=modifica2_camera.php method=post>
<br><br>
<pre>
<fieldset> <legend> <b> CAMERA </b> </legend>

Vecchio nome:  <INPUT TYPE=text NAME=name value='$nome_esc' maxlength=20 required> Prezzo giornaliero:  <INPUT TYPE=number step=0.01 NAME=prezzo value='$riga[prezzo]' required>

</fieldset>
<fieldset> <legend> <b> DATI AGGIORNATI DELLA CAMERA </b> </legend>
Ultimo cambio delle lenzuola      <INPUT TYPE=date NAME=cambio_lenzuola value='$riga[cambio_lenzuola]' MAX='$max->format(Y-m-d)'>
<BR>
Documenti obbligatori:  <select name='docum_obbligatori' value='$riga[docum_obbligatori]'>
                        <option value='presenti'> Presenti </option>
                        <option value='assenti'> Assenti</option>
                        </select>   Angolo tisane:  <select name='angolo_tisane' value='$riga[angolo_tisane]'>
                                                    <option value='fornito'> Fornito </option>
                                                    <option value='da rifornire'> Da rifornire </option>
                                                    </select>   Kit di cortesia:  <select name='kit_cortesia' value='$riga[kit_cortesia]'>
                                                                                  <option value='presente'>Presente</option>
                                                                                  <option value='da cambiare o rifornire'> Da cambiare o rifornire </option>
                                                                                  </select>
<br>
</fieldset>
</pre>
<input type=submit value=Conferma><br>");

mysqli_free_result($ris);
mysqli_close($con);

?>