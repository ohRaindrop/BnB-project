<?php

include   "..\database2.inc";

//Escape della stringa
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]" );

//Inserimento in DB
$insert= "INSERT INTO Camera (nome, prezzo)
         VALUES ('$nome_esc','$_POST[prezzo]')";

$result=mysqli_query($con,$insert);

if (!($result))
{
  echo("<br>Errore: ".mysqli_error($con));
  exit();
}
else
 {
   echo ("<br>Registrazione della nuova camera effettuata correttamente.");
 }


mysqli_close($con);

?>