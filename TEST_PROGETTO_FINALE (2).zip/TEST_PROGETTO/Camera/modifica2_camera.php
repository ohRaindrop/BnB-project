<?php
include   "..\database2.inc";

//escape
$new_esc=mysqli_real_escape_string ($con , "$_POST[new]");
$old_esc=mysqli_real_escape_string ($con , "$_POST[old]");

//attuazione della modifica sul DB
$update="UPDATE Camera
         SET nome='$new_esc', prezzo='$_POST[prezzo]', cambio_lenzuola='$_POST[cambio_lenzuola]', docum_obbligatori='$_POST[docum_obbligatori]',
             angolo_tisane='$_POST[angolo_tisane]',kit_cortesia='$_POST[kit_cortesia]'
         WHERE nome='$new_esc'";
$ris=mysqli_query($con,$update);

if(!$ris)
{
  echo("<br> Errore nel comando UPDATE: " .mysqli_error($con));
  exit();
}

echo("<br> Modifica dei dati della camera effettuata correttamente");

mysqli_close($con);
?>