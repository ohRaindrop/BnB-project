﻿<html>
<head>
<title>Gestione database</title>
<style>
div.transbox {
             margin: 150px 450px 50px 450px;
             background-color: #ffe6ff;
             border: 1px solid black;
             opacity: 0.75;
             filter: alpha(opacity=75);
}

div.transbox p {
    margin: 5%;
    font-weight: bold;
    color: #ff66ff;
}
</style>

</head>

<BODY>

<div class="transbox">
<center>

<?php
if(($_POST["pwd"] == "admin"))
   {
     echo("<br><br>La password e' corretta. <br>
           <br><br><a href='http://localhost/TEST_PROGETTO/index_2.htm'> Accedi all'area amministrativa </a>
	   <br><br>");
   }
else
   {
     echo("<br><br>La password e' errata.
           <br><br>
           <a href='http://localhost/TEST_PROGETTO/index.htm'> Riprova </a>
           <br><br>");
   }
?>

</center>
</div>

<BODY>
</html>