<?php
include  "..\database2.inc";

// operazione sul database e verifica di successo
$select= "SELECT *, prenotazione.id_lomb
          FROM Pagamento 
          INNER JOIN Prenotazione ON prenotazione.id_pren=pagamento.id_pren
          WHERE num_pagamento='$_POST[num_pagamento]'";

$ris=mysqli_query($con,$select);
$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if( (!$ris) OR (!$riga))
{
  echo("Errore: non sono presenti pagamenti".mysqli_error($con));
  exit();
}

// imposizione della data minima
$min= new DateTime;


//prima modifica
echo("<form action=modifica2_pagamento.php method=post>
<br><br>
Id del pagamento: <INPUT TYPE=text value=$riga[id_pagamento] readonly>
<br>
<pre>
<fieldset> <legend> <b> DATI DEL PAGAMENTO </b> </legend>
Numero del pagamento:  <INPUT TYPE=number NAME=num_pagamento value=$riga[num_pagamento]>   Forma di pagamento:  <select name=tipo value=$riga[tipo]>
                                                                                                                <option value=contanti> Contanti </option>
                                                                                                                <option value=Bancomat> Bancomat </option>
                                                                                                                <option value=Assegno> Assegno </option>
                                                                                                                <option value=POS> POS </option>
                                                                                                                </select>   Data del pagamento:  <INPUT TYPE=date NAME=data VALUE=$riga[data]>
Prenotazione di riferimento (id dato dalla Regione Lombardia):  <INPUT TYPE=text NAME=id_lomb value=$riga[id_lomb]><BR>
</fieldset>
<BR>
<fieldset> <legend> <b> DATI AGGIUNTIVI </b> </legend>
Se � presente una caparra e si vuole modificarla*: <INPUT TYPE=text NAME=caparra value=$riga[caparra]><BR>
Se � stato fatto uno sconto e si vuole modificarlo*: <INPUT TYPE=text NAME=sconto value=$riga[sconto]><BR>
TOTALE DEL PAGAMENTO DOVUTO: <INPUT TYPE=text NAME=totale value=$riga[totale]><BR>
</fieldset>
<br>
<br>
<input type=submit value=Conferma><br>
<br>
<br>");

mysqli_free_result($ris);
mysqli_close($con);

?>