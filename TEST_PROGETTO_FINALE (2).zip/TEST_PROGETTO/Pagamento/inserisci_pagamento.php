<HTML>
<BODY>

<FONT SIZE=3>
<h3>Inserimento dati del nuovo pagamento:</h3>

<?php
include "../database2.inc";

$min = new DateTime();

// estrazione dei dati necessari
$select= "SELECT Prenotazione.*,  Camera.prezzo AS prezzo, camera.nome
         FROM Prenotazione 
         INNER JOIN Relativa ON prenotazione.id_pren=relativa.id_pren
         INNER JOIN Camera ON relativa.nome_camera=camera.nome
         WHERE id_lomb='$_POST[id_lomb]'
         AND relativa.id_pren=prenotazione.id_pren
         AND relativa.nome_camera=camera.nome
         ";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result, MYSQLI_ASSOC);

if( (!$result) OR (!$riga) )
    {
      echo("Errore.") + mysqli_error($con);
      echo(" <br> Non sono presententi prenotazioni. Riprovare <a href='inserisci_nuovo_pagamento.php'> qui </a>");
      exit();
    }

$date_a = new DateTime("$riga[data_arrivo]");
$date_p = new DateTime("$riga[data_partenza]");
$diff=date_diff($date_a,$date_p);
$permanenza= (string)$diff->format('%R%a');

echo " <FORM ACTION='inserisci1_pagamento.php' METHOD='post'
 oninput=' totale.value=
            parseInt(caparra.value)
          + (( parseInt(adulti_matrimoniale.value)* parseInt(prezzo.value))
          + parseInt(altri_adulti.value)*15
          + parseInt(ragazzi.value)*15
          + parseInt(bambini_3_10.value)*10 ) * $permanenza
          - parseInt(sconto.value)' >

<pre>
Numero del pagamento*:  <INPUT TYPE='number' NAME='num_pagamento' required>   Forma di pagamento*:  <select name='tipo' required>
                                                                                           <option value='contanti'> Contanti </option>
                                                                                           <option value='Bancomat'> Bancomat </option>
                                                                                           <option value='Assegno'> Assegno </option>
                                                                                           <option value='POS'> POS </option>
                                                                                           </select>   Data del pagamento*:   <INPUT TYPE='date' NAME='data' value='".date("Y-m-d")."' required>
<BR>
Prenotazione di riferimento (id dato dalla Regione Lombardia e personale)*: <INPUT NAME='id_lomb' value='$_POST[id_lomb]' readonly> - <INPUT NAME='id_pren' value='$riga[id_pren]' readonly> <BR>

<BR>
Se � presente una caparra, inserirla: <INPUT TYPE='number' step='0.1' NAME='caparra' id='caparra' value='$riga[caparra]'><BR>
Se � stato fatto uno sconto <b>SUL TOTALE</b>, presentarlo: <INPUT TYPE='number' step='0.1' NAME='sconto' id='sconto' value='0'><BR>

Persone adulte*:
Adulti in camera matrimoniale o singola:  <INPUT TYPE='numer' min='1' id='adulti_matrimoniale' NAME='adulti_matrimoniale' value='$riga[adulti_matrimoniale]' required readonly>
Adulti in letto singolo (aggiuntivo):  <INPUT TYPE='numer' min='0' id='altri_adulti' NAME='altri_adulti' value='$riga[altri_adulti]' required readonly>
Ragazzi 10 - 18:  <INPUT TYPE='numer' min='0' id='ragazzi' NAME='ragazzi' value='$riga[ragazzi]' required readonly>

Bambini:
Bambini 0-3 anni:  <INPUT TYPE='numer' min='0' id='bambini_0_3' NAME='bimbi_0_3' value='$riga[bimbi_0_3]' required readonly>
Bambini 3-10 anni:  <INPUT TYPE='numer' min='0' id='bambini_3_10' NAME='bimbi_3_10' value='$riga[bimbi_3_10]' required readonly>


Costo della camera a notte:  <INPUT TYPE='number' step='0.1' id='prezzo' value='$riga[prezzo]'> <BR>
Permanenza totale: ".$permanenza= (string)$diff->format('%a')."giorni.

<FONT SIZE=5> TOTALE DEL PAGAMENTO DOVUTO: <input name='totale' id='totale'/>  </FONT> <BR>

<br><br>
<u>
<b>Nota</b>: i campi contrassegnati da <b>*</b> sono obbligatori. </u>                  <input type='submit' value='Aggiungi'>

</pre>

</FORM>";
?>
</BODY>
</HTML>