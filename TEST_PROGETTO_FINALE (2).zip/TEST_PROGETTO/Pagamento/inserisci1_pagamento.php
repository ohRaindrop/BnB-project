<?php

include "..\database2.inc";

$insert= "INSERT INTO Pagamento (id_pren, num_pagamento, tipo, data, caparra, sconto, totale)
          VALUES ( (SELECT prenotazione.id_pren
                    FROM prenotazione INNER JOIN effettua
                    WHERE id_lomb='$_POST[id_lomb]'
                    AND NOT (ruolo LIKE 'membro%')
                    AND effettua.id_pren=prenotazione.id_pren),
                   '$_POST[num_pagamento]','$_POST[tipo]','$_POST[data]','$_POST[caparra]','$_POST[sconto]','$_POST[totale]')";

$result=mysqli_query($con,$insert);

if (!($result))
   {
    echo("<br>Errore: ".mysqli_error($con));
    exit();
   }
else
    echo ("<br>Registrazione del pagamento ricevuto effettuata correttamente.");

mysqli_close($con);
?>