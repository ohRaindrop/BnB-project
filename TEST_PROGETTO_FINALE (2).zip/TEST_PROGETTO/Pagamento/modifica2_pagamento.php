<?php
include   "..\database2.inc";

//attuazione della modifica sul DB
$id_pren="SELECT DISTINCT prenotazione.id_pren, prenotazione.*, pagamento.sconto, pagamento.totale
                    FROM prenotazione 
                    INNER JOIN effettua ON prenotazione.id_pren=effettua.id_pren
                    INNER JOIN pagamento ON pagamento.id_pren=prenotazione.id_pren
                    WHERE prenotazione.id_lomb='$_POST[id_lomb]'
                    AND NOT (ruolo LIKE 'membro%')
          ";
$ris=mysqli_query($con,$id_pren);
$riga=mysqli_fetch_array($ris,MYSQLI_ASSOC);

$totale=$riga['totale']+$riga['sconto']-$_POST['sconto']+$riga['caparra']-$_POST['caparra'];
$update="UPDATE Pagamento
         SET num_pagamento='$_POST[num_pagamento]', tipo='$_POST[tipo]',
             id_pren=($riga[id_pren]),
             data='$_POST[data]', caparra='$_POST[caparra]', sconto='$_POST[sconto]', totale='$totale'
         WHERE num_pagamento='$_POST[num_pagamento]'";
$ris=mysqli_query($con,$update);

if(!$ris)
{
  echo("<br> Errore nel comando UPDATE: " .mysqli_error($con));
  exit();
}

echo("<br> Modifica dei dati del pagamento effettuata correttamente");

mysqli_close($con);

?>