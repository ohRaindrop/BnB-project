<HTML>
<HEAD> </HEAD>

<BODY>
<FONT SIZE=3>

<fieldset> <legend> <b> SCELTA DEL PAGAMENTO DI RIFERIMENTO </b> </legend>
<FORM ACTION="modifica1_pagamento.php" METHOD="POST">
<?php
include "../database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT num_pagamento, totale, id_lomb,cliente.nome
           FROM pagamento 
           INNER JOIN Prenotazione ON prenotazione.id_pren=pagamento.id_pren,
           effettua, cliente
           WHERE pagamento.id_pren=effettua.id_pren
           AND cliente.id_cliente=effettua.id_cliente
           order by pagamento.data";


$result=mysqli_query($con,$select);

if ((empty($result)))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca ".mysqli_error($con));
  exit();
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }
 if ((empty($rows)))
 {
   echo ("Non ci sono pagamenti da modificare.");
   exit();
 }


echo (" Scegliere il pagamento da modificare: <br>");

 foreach($rows as $riga)
 {
  echo (" <br><input type=radio name=num_pagamento value='$riga[num_pagamento]'> Pagamento numero: <b>$riga[num_pagamento]</b> di $riga[totale] �<br>
         &emsp; &emsp; &emsp; &emsp; &emsp; Effettuato da $riga[nome], riferito alla prenotazione con ID $riga[id_lomb]  <br>");
 }

}

?>
<br><br><br>
<input type="submit" value="Continua per modificare il pagamento">
</FORM>
</fieldset>

</BODY>
</HTML>