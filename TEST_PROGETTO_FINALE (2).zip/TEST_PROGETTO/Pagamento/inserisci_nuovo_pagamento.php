<HTML>
<BODY>

<fieldset> <legend> <b> PRENOTAZIONI DI RIFERIMENTO </b> </legend>
<FORM ACTION="inserisci_pagamento.php" METHOD="POST">

<?php
include "../database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT Cliente.id_cliente, nome, cognome, data_nascita, data_arrivo, data_partenza, Prenotazione.id_lomb
           FROM Cliente
           INNER JOIN effettua ON cliente.id_cliente=effettua.id_cliente
           INNER JOIN prenotazione ON prenotazione.id_pren=effettua.id_pren
           WHERE prenotazione.id_lomb!=0
           AND ruolo NOT LIKE 'membro%'
           AND prenotazione.id_pren NOT IN
               (SELECT id_pren FROM pagamento)
           GROUP BY id_lomb
           ORDER BY data_arrivo";


$result=mysqli_query($con,$select);

if ((empty($result)))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca ".mysqli_error($con));
  exit();
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }
 if ((empty($rows)))
 {
   echo ("Non ci sono prenotazioni da pagare.");
   exit();
 }


echo (" Scegliere il pagamento da modificare: <br>");

 foreach($rows as $riga)
 {
  $date_arrivo=new DateTime($riga['data_arrivo']);
  $date_partenza=new DateTime($riga['data_partenza']);
  echo (" <br><input type=radio name=id_lomb value='$riga[id_lomb]'> Prenotazione numero: <b>$riga[id_lomb]</b>
          <br> &emsp; &emsp; &emsp; &emsp; &emsp; Occupata <b>dal ". date_format($date_arrivo,'d/m/Y') ." al ". date_format($date_partenza,'d/m/Y') ."</b>
          da <b>$riga[cognome] $riga[nome] </b>. <br>  ");
 }

}

?>
<br><br><br>
<input type="submit" value="Continua per registrare il pagamento della prenotazione">
</FORM>
</fieldset>


</BODY>
</HTML>