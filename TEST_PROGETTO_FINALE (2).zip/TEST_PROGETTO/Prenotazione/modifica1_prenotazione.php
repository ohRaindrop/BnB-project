<?php
 include "..\database2.inc";

// select dei dati del cliente capogruppo, verifica del successo della query
$select_all= "SELECT distinct *, Cliente.nome AS nome_cliente
              FROM Cliente,Prenotazione,Camera,Effettua, Relativa
              WHERE Prenotazione.id_pren='$_POST[id_pren]'
              and cliente.id_cliente=effettua.id_cliente
              and relativa.id_pren=prenotazione.id_pren
              and effettua.id_pren=relativa.id_pren
              and effettua.id_pren=prenotazione.id_pren
              and camera.nome=relativa.nome_camera";
$result_select_all=mysqli_query($con,$select_all);

if( !($result_select_all) )
    {
      echo(" Il cliente non � presente all'interno del database. <BR>
             Per registrarlo, inserirne i dati <a href='..\Cliente\inserisci_cliente.php'> qui </a> <BR>
             Oppure inserire direttamente la prenotazione <a href='conferma_prenotazione_non_registrato.php'> qui </a> "
             .mysqli_error($con));
    }
else
    {
      $riga=mysqli_fetch_array($result_select_all, MYSQLI_ASSOC);
      if(!$riga)
        {
        echo("Dati non presenti nel database.<br>");
        echo("<a href='conferma_prenotazione.php'> Riprova </a>");
        exit();
        }
    }


$max = new DateTime();
$min = new DateTime();

$data_arrivo=str_replace(" ", "T", $riga['data_arrivo']);
$data_partenza=str_replace(" ", "T", $riga['data_partenza']);

//$numero_persone=$riga['adulti_matrimoniale']+$riga['bimbi_0_3']+$riga['bimbi_3_10']+$riga['ragazzi']+$riga['altri_adulti'];

echo ("
<h1> Modifica della prenotazione selezionata </h1>
<FORM ACTION=modifica2_prenotazione.php METHOD=post>
<pre>
<fieldset><legend><b> DATI DELLA PRENOTAZIONE </b></legend>
ID della prenotazione <INPUT TYPE=number NAME=id_pren  readonly value=$riga[id_pren]>
ID fornito dalla regione Lombardia: <INPUT TYPE=text NAME=id_lomb maxlength=10 required  value=$riga[id_lomb]>
Canale di prenotazione:  <INPUT TYPE=text NAME=canale_prenot maxlength=20  required  value=$riga[canale_prenot]>
Data di arrivo:  <INPUT TYPE=datetime-local NAME=data_arrivo  required value='$data_arrivo'>   Data di partenza:  <INPUT TYPE=datetime-local NAME=data_partenza  MIN=$riga[data_arrivo] required value=$data_partenza>
Eventuale caparra*:  <INPUT TYPE=number NAME=caparra step=0.1 value=$riga[caparra]> <BR>

Ruolo del cliente:  <select name=ruolo  required>");
if ($riga['ruolo']=="ospite singolo")
{
  echo("<option value='ospite singolo' selected='selected'> Ospite singolo </option>");
}
else
{
  echo ("<option value='ospite singolo'> Ospite singolo </option>");
}  
if ($riga['ruolo']=="capo famiglia")
{
  echo("<option value='capo famiglia' selected='selected'> Capo famiglia </option> ");
}
else
{
  echo ("<option value='capo famiglia'> Capo famiglia </option>");
} 
if ($riga['ruolo']=="capo gruppo")
{
  echo("<option value='capo gruppo' selected='selected'> Capo Gruppo </option>");
}
else
{
  echo ("<option value='capo gruppo'> Capo Gruppo </option>");
} 
echo ("                   <option value='membro del gruppo'> Membro del gruppo </option>
                    <option value='membro della famiglia'> Membro della famiglia </option>
                    </select>

Persone adulte*:
Adulti in camera matrimoniale o singola:  <INPUT TYPE='numer' min='1' id='adulti_matrimoniale' NAME='adulti_matrimoniale' value='$riga[adulti_matrimoniale]' required>
Adulti in letto singolo (aggiuntivo):  <INPUT TYPE='numer' min='0' id='altri_adulti' NAME='altri_adulti' value='$riga[altri_adulti]' required>
Ragazzi 10 - 18:  <INPUT TYPE='numer' min='0' id='ragazzi' NAME='ragazzi' value='$riga[ragazzi]' required>

Bambini:
Bambini 0-3 anni:  <INPUT TYPE='numer' min='0' id='bimbi_0_3' NAME='bimbi_0_3' value='$riga[bimbi_0_3]' required>
Bambini 3-10 anni:  <INPUT TYPE='numer' min='0' id='bimbii_3_10' NAME='bimbi_3_10' value='$riga[bimbi_3_10]' required>

</fieldset>

<fieldset><legend><b> DATI DELLA CAMERA </b></legend>
Nome:  <INPUT TYPE=text NAME=nome_camera required value=$riga[nome_camera]>   Prezzo:  <INPUT TYPE=number NAME=prezzo  step=0.1 required value=$riga[prezzo]>   Numero di persone:  <INPUT TYPE=number NAME=num_persone  required value=$riga[num_persone]>
</fieldset>


                                  <input type=submit value=Inserisci>

</pre>
</FORM>
<BR><BR>");

echo ("<BR><BR>");

/*errore min=$min->format(Y-m-d) e max=$max->format(Y-m-d) */
?>