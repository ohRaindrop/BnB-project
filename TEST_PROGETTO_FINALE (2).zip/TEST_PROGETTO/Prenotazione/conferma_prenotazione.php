<HTML>
<BODY>

<fieldset> <legend> <b> SCELTA DELLA PRENOTAZIONE DI RIFERIMENTO </b> </legend>
<FORM ACTION="conferma_prenotazione_registrato.php" METHOD="POST">

<?php
include "../database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT Cliente.id_cliente, nome, cognome, nome_camera, data_arrivo, data_partenza, ruolo, identificatore,
                           Prenotazione.id_pren , id_lomb
           FROM Cliente, Prenotazione, Effettua, relativa
           WHERE id_lomb='000'
           AND Cliente.id_cliente in
                 (SELECT DISTINCT id_cliente
                  FROM Effettua as E2
                  WHERE cliente.id_cliente=E2.id_cliente and Prenotazione.id_pren=E2.id_pren
                   and E2.id_effettua=effettua.id_effettua
                 AND (ruolo like 'ospite%' OR ruolo like 'capo%'))
           and  relativa.id_pren = prenotazione.id_pren
           ";


$result=mysqli_query($con,$select);

if ((empty($result)))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca ".mysqli_error($con));
  exit();
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }
 if ((empty($rows)))
 {
   echo ("Non ci sono prenotazioni da confermare.");
   exit();
 }


echo (" Scegliere la prenotazione da confermare: <br>");

 foreach($rows as $riga)
 {
  $date_arrivo=new DateTime($riga['data_arrivo']);
  $date_partenza=new DateTime($riga['data_partenza']);
  echo (" <br><input type=radio name=id_pren value='$riga[id_pren]'> Camera: <b>$riga[nome_camera]</b>
          <br> &emsp; &emsp; &emsp; &emsp; &emsp; Occupata <b>dal ". date_format($date_arrivo,'d/m/Y') ." al ". date_format($date_partenza,'d/m/Y') ."</b>
          da <b>$riga[cognome] $riga[nome] </b>- $riga[ruolo]. <br>  ");
 }

}

?>
<br><br><br>
<input type="submit" value="Continua per confermare la prenotazione dell'utente gi� registrato">
</FORM>
</fieldset>


</BODY>
</HTML>