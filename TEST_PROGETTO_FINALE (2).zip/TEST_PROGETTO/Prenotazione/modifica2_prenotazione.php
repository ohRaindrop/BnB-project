<?php

include   "..\database2.inc";

//-------------------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE nella tabella Prenotazione
$update_prenotazione= "UPDATE Prenotazione
                       SET data_arrivo='$_POST[data_arrivo]',data_partenza='$_POST[data_partenza]',caparra='$_POST[caparra]',
                           adulti_matrimoniale='$_POST[adulti_matrimoniale]',bimbi_0_3='$_POST[bimbi_0_3]', bimbi_3_10='$_POST[bimbi_3_10]',
                           ragazzi='$_POST[ragazzi]', altri_adulti='$_POST[altri_adulti]'
                       WHERE id_pren='$_POST[id_pren]'";
$result_prenotazione=mysqli_query($con,$update_prenotazione);


//-------------------------------------------------------------------------------------------------------------------------------------------------------
// UPDATE della tabella Camera

$update_camera= "UPDATE Camera
                 SET prezzo = '$_POST[prezzo]', cambio_lenzuola=now(),
                 docum_obbligatori='presenti', angolo_tisane='fornito', kit_cortesia='presente',
                 WHERE nome='$_POST[nome_camera]'";
$result_camera=mysqli_query($con, $update_camera);


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE nella tabella Effettua
$update_effettua= "UPDATE Effettua
                   SET canale_prenot='$_POST[canale_prenot]', ruolo='$_POST[ruolo]'
                   WHERE id_pren='$_POST[id_pren]'";
$result_effettua=mysqli_query($con, $update_effettua);
/*$update_effettua= "UPDATE Effettua
                   SET canale_prenot='$_POST[canale_prenot]', ruolo='$_POST[ruolo]'
                   WHERE id_lomb='$_POST[id_lomb]'";
$result_effettua=mysqli_query($con, $update_effettua);
*/


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE nella tabella Relativa
$numero_persone=$_POST['adulti_matrimoniale']+$_POST['bimbi_0_3']+$_POST['bimbi_3_10']+$_POST['ragazzi']+$_POST['altri_adulti'];
$update_relativa= "UPDATE Relativa
                   SET num_persone='$numero_persone'
                   WHERE id_pren='$_POST[id_pren]' AND nome_camera='$_POST[nome_camera]' ";
$result_relativa=mysqli_query($con, $update_relativa);
/*$update_relativa= "UPDATE Relativa
                   SET num_persone='$numero_persone'
                   WHERE id_lomb='$_POST[id_lomb]' AND nome_camera='$_POST[nome_camera]' ";
$result_relativa=mysqli_query($con, $update_relativa);
*/



// Verifica della corretta esecuzione delle query
if (!($result_effettua) AND !($result_prenotazione) AND !($result_relativa) AND !($result_camera))
{
  echo("<br>Errore: uno dei dati inseriti � errato. ".mysqli_error($con));
  exit();
}
else
 {
   echo ("<br>Prenotazione modificata correttamente.<BR><BR>");
 }


mysqli_close($con);

?>