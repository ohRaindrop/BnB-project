<HTML>
<HEAD>
       <script>

function myID()
{
        var nome = (document.getElementById("nome").value).substring(0,3);
        var cognome = (document.getElementById("cognome").value).substring(0,3);
        var data = new Date(document.getElementById("data_nascita").value).getFullYear().toString();

        document.getElementById("identificatore").innerHTML = nome.toUpperCase() + cognome.toUpperCase() + data.substring(2,4);
}

</script>
</HEAD>

<BODY>
<FONT SIZE=3>

<?php
$max = new DateTime();
$min = new DateTime(); 


echo (" <h1> Inserimento della prenotazione provvisoria </h1>
<FORM ACTION='inserisci_prenotazione_provvisoria1.php' METHOD='post'>
<pre>
<fieldset><legend><b>DATI DEL CLIENTE </b></legend>
Nome:  <INPUT TYPE='text' NAME='nome' id='nome' maxlength=30 required oninput='myID()'>   Cognome:  <INPUT TYPE='text' id='cognome' NAME='cognome' maxlength=30 required oninput='myID()'>   Sesso:  <select name='sesso' required>
                                                                                                                                            <option value='Uomo'>Uomo</option>
                                                                                                                                            <option value='Donna'>Donna</option>
                                                                                                                                            </select>   Telefono (opzionale):  <INPUT TYPE='tel' NAME='telefono' maxlength=10>


Data di nascita:  <INPUT TYPE='date' id='data_nascita' NAME='data_nascita' oninput='myID()' required>
Ruolo del cliente:  <select name='ruolo' required>
                    <option value='ospite singolo'> Ospite singolo </option>
                    <option value='capo gruppo'> Capogruppo </option>
                    <option value='capo famiglia'> Capofamiglia</option>
                    </select> <BR>

</fieldset>

<fieldset><legend><b> DATI DELLA PRENOTAZIONE </b></legend>
Canale di prenotazione:  <INPUT TYPE='text' NAME='canale_prenot' maxlength=20 required>
Data di arrivo:  <INPUT TYPE='datetime-local' NAME='data_arrivo' value='$_POST[data_arrivo]' required>   Data di partenza:  <INPUT TYPE='datetime-local' NAME='data_partenza'  value='$_POST[data_partenza]' required>
Eventuale caparra (opzionale):  <INPUT TYPE='number' NAME='caparra' step=0.1 value='0'> <BR>
</fieldset>
</pre>

<fieldset><legend><b> DATI DELLA CAMERA </b></legend>");
include 'camere_libere.php';
echo("<pre>
Conferma  o modifica del prezzo a notte:  <INPUT TYPE='number' NAME='prezzo' id=prezzo value=step=0.01 required>

Numero di persone:  <INPUT TYPE='number' NAME='num_letti' required>
</fieldset>

<center> <input type='submit' value='Inserisci'> </center>

</pre>

</FORM>
");
?>
</BODY>
</HTML>