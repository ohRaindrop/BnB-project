<?php

include   "..\database2.inc";

//escape
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]");
$cognome_esc=mysqli_real_escape_string ($con , "$_POST[cognome]");
$luogo_nascita_esc=mysqli_real_escape_string ($con , "$_POST[luogo_nascita]");
$canale_prenot_esc=mysqli_real_escape_string ($con , "$_POST[canale_prenot]");
$ruolo_esc=mysqli_real_escape_string ($con , "$_POST[ruolo]");
$mail_esc=mysqli_real_escape_string ($con , "$_POST[mail]");
$indirizzo_esc=mysqli_real_escape_string ($con , "$_POST[indirizzo]");
                            
//controlli su id_lomb
$select_id_lomb= " SELECT distinct id_lomb
                   FROM prenotazione
                   WHERE prenotazione.id_lomb='$_POST[id_lomb]'
                 ";
$res_sel=mysqli_query($con,$select_id_lomb);
$riga=mysqli_fetch_array($res_sel,MYSQLI_ASSOC);
while($riga)
{
  if(empty($res_sel));
  echo("Errore: l'id della regione lombardia e' sbagliato e risulta essere gia' presente.");
  exit();
}


//UPDATE nella tabella Cliente
$update_cliente= "UPDATE Cliente
                        SET nome='$nome_esc', cognome='$cognome_esc', tipo_id='$_POST[tipo_id]', identificatore='$_POST[identificatore]',
                            sesso='$_POST[sesso]', luogo_nascita='$luogo_nascita_esc', data_nascita='$_POST[data_nascita]', indirizzo='$indirizzo_esc',
                            mail='$mail_esc', telefono='$_POST[telefono]', cittadinanza='$_POST[cittadinanza]', tipo_doc_ric='$_POST[tipo_doc_ric]',
                            numero_doc_ric='$_POST[numero_doc_ric]', luogo_rilascio='$_POST[luogo_rilascio]', data_rilascio='$_POST[data_rilascio]'
                        WHERE id_cliente='$_POST[id_cliente]'";
$result_cliente=mysqli_query($con, $update_cliente);
  if ((empty($result_cliente)))
{ 
  echo mysqli_error($con);
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE nella tabella Prenotazione
$update_prenotazione= "UPDATE Prenotazione
                       SET id_lomb='$_POST[id_lomb]',data_arrivo='$_POST[data_arrivo]',data_partenza='$_POST[data_partenza]',caparra='$_POST[caparra]',
                           adulti_matrimoniale='$_POST[adulti_matrimoniale]',bimbi_0_3='$_POST[bimbi_0_3]', bimbi_3_10='$_POST[bimbi_3_10]',
                           ragazzi='$_POST[ragazzi]', altri_adulti='$_POST[altri_adulti]'
                       WHERE id_pren='$_POST[id_pren]'
                       ";
$result_prenotazione=mysqli_query($con,$update_prenotazione);



//-------------------------------------------------------------------------------------------------------------------------------------------------------
// UPDATE della tabella Camera
$update_camera= "UPDATE Camera
                 SET prezzo = '$_POST[prezzo]', cambio_lenzuola=now(),
                 docum_obbligatori='presenti', angolo_tisane='fornito',kit_cortesia='presente'
                 WHERE nome='$_POST[nome_camera]'";
$result_camera=mysqli_query($con, $update_camera);


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE nella tabella Effettua
$update_effettua= "UPDATE Effettua
                   SET canale_prenot='$_POST[canale_prenot]', ruolo='$_POST[ruolo]'
                   WHERE id_pren='$_POST[id_pren]'";
$result_effettua=mysqli_query($con, $update_effettua);


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE nella tabella Relativa
$numero_persone=$_POST['adulti_matrimoniale']+$_POST['bimbi_0_3']+$_POST['bimbi_3_10']+$_POST['ragazzi']+$_POST['altri_adulti'];
$update_relativa= "UPDATE Relativa
                   SET num_persone='$numero_persone'
                   WHERE id_pren='$_POST[id_pren]' AND nome_camera='$_POST[nome_camera]' ";
$result_relativa=mysqli_query($con, $update_relativa);



// Verifica della corretta esecuzione delle query
if ((empty($result_cliente)))
{
  if(empty($result_effettua))
{ 
  if (empty($result_prenotazione))
  {
    if(empty($result_relativa))
    {
      if(empty($result_camera))
      {
       echo("<br>Errore fino a camera: uno dei dati inseriti � errato. ".mysqli_error($con));
       exit();
      }
    echo("<br>Errore fino a relativa: uno dei dati inseriti � errato. ".mysqli_error($con));
    exit();
    }
   echo("<br>Errore fino a prenotazione: uno dei dati inseriti � errato. ".mysqli_error($con));
   exit();
  }
  echo("<br>Errore fino a effettua: uno dei dati inseriti � errato. ".mysqli_error($con));
  exit();
}
echo("<br>Errore fino a cliente: uno dei dati inseriti � errato. ".mysqli_error($con));
exit();
}
else
 {
   echo ("<br>Conferma della prenotazione effettuata correttamente.<BR><BR>");
   if ($numero_persone>1)
   {
     echo ("<form action='conferma_prenotazione_non_registrato.php' method=post>
           Prosegui con la conferma della prenotazione degli altri membri <br>
           (Prenotazione <input type='text' name=id_lomb value='$_POST[id_lomb]' readonly>)
           <input type='hidden' name=id_pren value='$_POST[id_pren]' readonly>
           <input type=submit value=Prosegui>
           ");
   }
 }


mysqli_close($con);
?>