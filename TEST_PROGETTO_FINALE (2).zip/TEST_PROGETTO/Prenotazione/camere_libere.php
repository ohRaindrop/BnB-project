<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= " SELECT nome, prezzo
           FROM Camera
           WHERE nome NOT  IN
                     (
                      SELECT distinct nome_camera
                      FROM Relativa
          	      INNER JOIN PRENOTAZIONE ON relativa.id_pren=prenotazione.id_pren
                      WHERE (prenotazione.data_arrivo>='$_POST[data_arrivo]'
                             AND prenotazione.data_arrivo<'$_POST[data_partenza]'
                             )
                      OR
                             (
                             prenotazione.data_partenza>'$_POST[data_arrivo]'
                             AND prenotazione.data_partenza<'$_POST[data_partenza]'
                             )
                      OR
                             (
                             prenotazione.data_arrivo<'$_POST[data_arrivo]'
                             AND prenotazione.data_partenza>'$_POST[data_partenza]'
                             )
                      )
           ";

$result=mysqli_query($con,$select);

if ((!$result) )
{
  echo("Errore: Non esistono camere libere nel periodo. ".mysqli_error($con));
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }

 foreach($rows as $riga)
 {
    echo (" <input type=radio id=nome_cam name=nome_camera value='$riga[nome]'> Camera: $riga[nome], prezzo a notte: $riga[prezzo] <br>");
 }
}
 



mysqli_free_result($result);
mysqli_close($con);
?>