<?php

include   "..\database2.inc";

//escape
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]");
$cognome_esc=mysqli_real_escape_string ($con , "$_POST[cognome]");
$luogo_nascita_esc=mysqli_real_escape_string ($con , "$_POST[luogo_nascita]");
$canale_prenot_esc=mysqli_real_escape_string ($con , "$_POST[canale_prenot]");
$ruolo_esc=mysqli_real_escape_string ($con , "$_POST[ruolo]");
$mail_esc=mysqli_real_escape_string ($con , "$_POST[mail]");
$indirizzo_esc=mysqli_real_escape_string ($con , "$_POST[indirizzo]" );
$luogo_rilascio_esc=mysqli_real_escape_string ($con , "$_POST[luogo_rilascio]" );
$tipo_id_esc=mysqli_real_escape_string ($con , "$_POST[tipo_id]" );
$tipo_doc_ric_esc=mysqli_real_escape_string ($con , "$_POST[tipo_doc_ric]" );

//presi alcuni dati dal capo di riferimento
$select_all="SELECT DISTINCT Cliente.nome as nome_cliente, CLIENTE.*, prenotazione.*, effettua.*, relativa.*,CAMERA.*
              FROM Cliente
              INNER JOIN effettua ON effettua.id_cliente=cliente.id_cliente
              INNER JOIN prenotazione ON effettua.id_pren=prenotazione.id_pren
             INNER JOIN relativa ON relativa.id_pren=prenotazione.id_pren
              INNER JOIN camera ON relativa.nome_camera=camera.nome
              WHERE Prenotazione.id_lomb='$_POST[id_lomb]'
              AND Cliente.id_cliente in
                 (SELECT DISTINCT id_cliente
                  FROM Effettua
                  WHERE cliente.id_cliente=Effettua.id_cliente and Prenotazione.id_pren=Effettua.id_pren)
                  ";

$result_select_all=mysqli_query($con,$select_all);
$riga=mysqli_fetch_array($result_select_all, MYSQLI_ASSOC);

//INSERT nella tabella Cliente
$insert_cliente= "INSERT INTO Cliente (nome, cognome, identificatore, tipo_id, sesso, luogo_nascita, data_nascita, indirizzo, mail, telefono, cittadinanza,
                               tipo_doc_ric, numero_doc_ric,luogo_rilascio, data_rilascio)
         VALUES ('$nome_esc','$cognome_esc','$_POST[identificatore]','$tipo_id_esc','$_POST[sesso]','$luogo_nascita_esc','$_POST[data_nascita]',
                 '$indirizzo_esc','$_POST[mail]','$_POST[telefono]','$_POST[cittadinanza]','$tipo_doc_ric_esc','$_POST[numero_doc_ric]',
                 '$luogo_rilascio_esc','$_POST[data_rilascio]');";
      $result_cliente=mysqli_query($con, $insert_cliente);

//$result=mysqli_num_rows($result_cliente)==1;

if( (empty($result_cliente)))
    {
       echo("<br>Errore cliente: uno dei dati inseriti � errato. ".mysqli_error($con));
       exit();
    }



//-------------------------------------------------------------------------------------------------------------------------------------------------------
//INSERT nella tabella Prenotazione
$insert_prenotazione= "INSERT INTO Prenotazione (id_lomb, data_arrivo, data_partenza, caparra, adulti_matrimoniale, bimbi_0_3, bimbi_3_10,
                                                 ragazzi, altri_adulti)
                       VALUES ('$_POST[id_lomb]','$_POST[data_arrivo]','$_POST[data_partenza]','$_POST[caparra]','$riga[adulti_matrimoniale]',
                               '$riga[bimbi_0_3]','$riga[bimbi_3_10]','$riga[ragazzi]','$riga[altri_adulti]')";
$result_prenotazione=mysqli_query($con,$insert_prenotazione);

if (empty($result_prenotazione))
 {
 echo("<br>Errore prenotazione: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//INSERT nella tabella Effettua
$insert_effettua= "INSERT INTO Effettua (id_pren, id_cliente, data,canale_prenot, ruolo)
                   VALUES ( (SELECT id_pren FROM Prenotazione ORDER BY id_pren DESC LIMIT 1),
                            (SELECT id_cliente FROM Cliente WHERE nome='$nome_esc' AND cognome='$cognome_esc' 
                                                                  AND data_nascita='$_POST[data_nascita]' AND luogo_nascita='$luogo_nascita_esc'),
                            now(),'$canale_prenot_esc','$ruolo_esc')";
$result_effettua=mysqli_query($con, $insert_effettua);
if (!$result_effettua)
 {
 echo("<br>Errore effettua: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//INSERT nella tabella Relativa
$numero_persone=$riga['adulti_matrimoniale']+$riga['bimbi_0_3']+$riga['bimbi_3_10']+$riga['ragazzi']+$riga['altri_adulti'];
$insert_relativa= "INSERT INTO Relativa (id_pren, nome_camera, num_persone)
                   VALUES ( (SELECT id_pren FROM Prenotazione ORDER BY id_pren DESC LIMIT 1),
                            '$_POST[nome_camera]','$numero_persone')";
$result_relativa=mysqli_query($con, $insert_relativa);

if (!$result_relativa)
 {
 echo("<br>Errore relativa: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }



// Verifica della corretta esecuzione delle query
if ((empty($result_cliente)))
{
  if(empty($result_effettua))
{ 
  if (empty($result_prenotazione))
  {
    if(empty($result_relativa))
    {
      if(empty($result_camera))
      {
       echo("<br>Errore fino a camera: uno dei dati inseriti � errato. ".mysqli_error($con));
       exit();
      }
    echo("<br>Errore fino a relativa: uno dei dati inseriti � errato. ".mysqli_error($con));
    exit();
    }
   echo("<br>Errore fino a prenotazione: uno dei dati inseriti � errato. ".mysqli_error($con));
   exit();
  }
  echo("<br>Errore fino a effettua: uno dei dati inseriti � errato. ".mysqli_error($con));
  exit();
}
echo("<br>Errore fino a cliente: uno dei dati inseriti � errato. ".mysqli_error($con));
exit();
}
else
 {
   $count=" SELECT COUNT(id_lomb) AS numero
            FROM prenotazione
            WHERE id_lomb='$_POST[id_lomb]'
         ";
   $select="SELECT id_pren FROM Prenotazione ORDER BY id_pren DESC LIMIT 1";
   $result_count=mysqli_query($con, $count);
   $result_select=mysqli_query($con, $select);
   $riga_count=mysqli_fetch_array($result_count, MYSQLI_ASSOC);
   $riga_select=mysqli_fetch_array($result_select, MYSQLI_ASSOC);


   echo ("<br>Conferma della prenotazione effettuata correttamente.<BR><BR>");
   if ($riga_count['numero']<$numero_persone)
   {
     echo ("Sono state registrate $riga_count[numero] persone su $numero_persone. <br>");
     echo ("<form action='conferma_prenotazione_non_registrato.php' method=post>
           Prosegui con la conferma della prenotazione degli altri membri <br>
           (Prenotazione <input type='text' name=id_lomb value='$_POST[id_lomb]' readonly>)
           <input type='hidden' name=id_pren value='$riga_select[id_pren]' readonly>
           <input type=submit value=Prosegui>
           </form>
           ");
   }
 }
?>