<?php
 include "..\database2.inc";
 
// select dei dati del cliente capo, verifica del successo della query
$select_all= "SELECT DISTINCT *, Cliente.nome as nome_cliente
              FROM Cliente, relativa,effettua,camera,prenotazione
              WHERE Prenotazione.id_pren='$_POST[id_pren]'
              AND Cliente.id_cliente in
                 (SELECT DISTINCT id_cliente
                  FROM Effettua
                  WHERE cliente.id_cliente=Effettua.id_cliente and Prenotazione.id_pren=Effettua.id_pren)
             AND cliente.id_cliente=Effettua.id_cliente
             AND Prenotazione.id_pren=Effettua.id_pren
           	 AND prenotazione.id_pren=relativa.id_pren
             AND relativa.id_pren=effettua.id_pren
             AND camera.nome=relativa.nome_camera
             ";
$result_select_all=mysqli_query($con,$select_all);

if( !($result_select_all) )
    {
      echo(" Il cliente non � presente all'interno del database. <BR>
             Per registrarlo, inserirne i dati <a href='..\Cliente\inserisci_cliente.php'> qui </a> <BR>
             Oppure inserire direttamente la prenotazione <a href='conferma_prenotazione_non_registrato.php'> qui </a> "
             .mysqli_error($con));
    }
else
    {
      $riga=mysqli_fetch_array($result_select_all, MYSQLI_ASSOC);
      if(!$riga)
        {
        echo("Dati non presenti nel database.<br>");
        echo("<a href='conferma_prenotazione.php'> Riprova </a>");
        exit();
        }
    }


$max = new DateTime();
$min = new DateTime(); 
$data_arrivo=str_replace(" ", "T", $riga['data_arrivo']);
$data_partenza=str_replace(" ", "T", $riga['data_partenza']);

echo ("
<h1> Conferma delle prenotazioni </h1>
<FORM ACTION=conferma_prenotazione_registrato1.php METHOD=post>
<pre>
<fieldset><legend><b>DATI DEL CLIENTE <input type='hidden' value='$riga[id_cliente]' name='id_cliente'> </b></legend>
Nome:  <INPUT TYPE=text NAME=nome maxlength=30 value='$riga[nome_cliente]' required>   Cognome:  <INPUT TYPE=text NAME=cognome maxlength=30 value='$riga[cognome]' required>   Sesso:  <select name=sesso required value='$riga[sesso]'>
                                                                                                                                                                                   <option value=Uomo>Uomo</option>
                                                                                                                                                                                   <option value=Donna>Donna</option></select>
Tipo di identificatore*: <select name='tipo_id' required>
                        <option value='Codice fiscale'>Codice fiscale</option>
                        <option value='Partita IVA'>Partita IVA</option>
                        <option value='Altro'>Altro</option>
                        </select> Identificatore*: <INPUT TYPE='text' NAME='identificatore' value='$riga[identificatore]' title='Inserire una stringa identificativa' required>
                                                                                                                                                                                   </select>
Luogo di nascita:  <INPUT TYPE=text NAME=luogo_nascita maxlength=50 value='$riga[luogo_nascita]' required>   Data di nascita:  <INPUT TYPE=date NAME=data_nascita value='$riga[data_nascita]'  required><BR>
Ruolo del cliente:  <select name=ruolo  required>");
if ($riga['ruolo']=="ospite singolo")
{
  echo("<option value='ospite singolo' selected='selected'> Ospite singolo </option>");
}
else
{
  echo ("<option value='ospite singolo'> Ospite singolo </option>");
}  
if ($riga['ruolo']=="capo famiglia")
{
  echo("<option value='capo famiglia' selected='selected'> Capo famiglia </option> ");
}
else
{
  echo ("<option value='capo famiglia'> Capo famiglia </option>");
} 
if ($riga['ruolo']=="capo gruppo")
{
  echo("<option value='capo gruppo' selected='selected'> Capo Gruppo </option>");
}
else
{
  echo ("<option value='capo gruppo'> Capo Gruppo </option>");
} 
echo ("    </select>

Indirizzo:  <INPUT TYPE=text NAME=indirizzo maxlength=100 value='$riga[indirizzo]' >   Indirizzo email:  <INPUT TYPE=email NAME=mail maxlength=50  pattern=[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{3,}$ title='nel formato user@dominio.it'  value='$riga[mail]'>   Telefono:  <INPUT TYPE=tel NAME=telefono maxlength=10   title='Non inserire il +39' value='$riga[telefono]'>

Cittadinanza:  <INPUT TYPE=text NAME=cittadinanza value='$riga[cittadinanza]'><BR>
Documento di riconoscimento:
          Tipo:  <select name=tipo_doc_ric value='$riga[tipo_doc_ric]' >
                 <option value=carta di identita> Carta d'identit� </option>
                 <option value=patente> Patente </option>
                 <option value=passaporto> Passaporto </option>
                 </select>   Numero:  <INPUT TYPE=text NAME=numero_doc_ric maxlength=20 required value='$riga[numero_doc_ric]'>

          Luogo di rilascio:  <INPUT TYPE=text NAME=luogo_rilascio maxlength=50 value='$riga[luogo_rilascio]'>   Data di rilascio:  <INPUT TYPE=date NAME=data_rilascio required value='$riga[data_rilascio]'><BR> <BR>

</fieldset>

<fieldset><legend><b> DATI DELLA PRENOTAZIONE </b></legend>
ID della prenotazione <INPUT TYPE=number NAME=id_pren  readonly value='$riga[id_pren]'>
ID fornito dalla regione Lombardia: <INPUT TYPE=text NAME=id_lomb maxlength=10 required  value='$riga[id_lomb]'>
Canale di prenotazione:  <INPUT TYPE=text NAME=canale_prenot maxlength=20  required  value='$riga[canale_prenot]'>

Persone adulte*:
Adulti in camera matrimoniale o singola:  <INPUT TYPE='numer' min='1' id='adulti_matrimoniale' NAME='adulti_matrimoniale' value='$riga[adulti_matrimoniale]' required>
Adulti in letto singolo (aggiuntivo):  <INPUT TYPE='numer' min='0' id='altri_adulti' NAME='altri_adulti' value='$riga[altri_adulti]' required>
Ragazzi 10 - 18:  <INPUT TYPE='numer' min='0' id='ragazzi' NAME='ragazzi' value='$riga[ragazzi]' required>

Bambini:
Bambini 0-3 anni:  <INPUT TYPE='numer' min='0' id='bambini_0_3' NAME='bimbi_0_3' value='$riga[bimbi_0_3]' required>
Bambini 3-10 anni:  <INPUT TYPE='numer' min='0' id='bambini_3_10' NAME='bimbi_3_10' value='$riga[bimbi_3_10]' required>

Data di arrivo:  <INPUT TYPE='datetime-local' NAME='data_arrivo'  required value='$data_arrivo'>
Data di partenza:  <INPUT TYPE='datetime-local' NAME=data_partenza  MIN='$riga[data_arrivo]' required value='$data_partenza'>
Eventuale caparra*:  <INPUT TYPE=number NAME=caparra step=0.1 value='$riga[caparra]'> <BR>
</fieldset>

<fieldset><legend><b> DATI DELLA CAMERA </b></legend>
Nome:  <INPUT TYPE=text NAME=nome_camera required value='$riga[nome_camera]'>   Prezzo:  <INPUT TYPE=number NAME=prezzo  step=0.1 required value='$riga[prezzo]'>

</fieldset>


                                  <input type=submit value=Inserisci>

</pre>
</FORM>
<BR><BR>");
?>