<HTML>
<BODY>

<FONT SIZE=3>

<?php
$max = new DateTime();
$min = new DateTime(); 
?>

<h1> Inserimento della prenotazione provvisoria </h1>
<FORM ACTION="camere_occupate.php" METHOD="post">

<pre>
<fieldset><legend><b>CONTROLLO DELLE DATE </b></legend>

Data di arrivo:  <INPUT TYPE="datetime-local" NAME="data_arrivo" MIN=<?php $min->format("Y-m-d")?> required>
Data di partenza:  <INPUT TYPE="datetime-local" NAME="data_partenza" MIN=<?php $min->format("Y-m-d")?> required>


<center> <input type="submit" value="Controlla le date"> </center>


</fieldset>
</pre>
</FORM>


</BODY>
</HTML>