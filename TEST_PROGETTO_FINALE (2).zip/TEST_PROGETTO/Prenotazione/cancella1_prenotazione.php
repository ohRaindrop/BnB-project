<?php
include   "..\database2.inc";

$delete= "DELETE
         FROM Prenotazione
         WHERE id_pren=$_POST[id_pren]
          ";



if(!mysqli_query($con,$delete))
{
  echo("<br> Errore: ".mysqli_error($con));
  exit();
}
else
 echo ("<br> I dati della prenotazione sono stati cancellati correttamente.");

mysqli_close($con);

?>