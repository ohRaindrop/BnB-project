<HTML>
<BODY>

<fieldset> <legend> <b> SCELTA DELLA PRENOTAZIONE DI RIFERIMENTO </b> </legend>
<FORM ACTION="modifica1_prenotazione.php" METHOD="POST">

<?php
include "../database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT Cliente.id_cliente, nome, cognome, data_nascita, tipo_id, identificatore, Prenotazione.id_pren , id_lomb,data_arrivo, data_partenza
           FROM Cliente, Prenotazione INNER JOIN Effettua
           WHERE Cliente.id_cliente in
                 (SELECT DISTINCT id_cliente
                  FROM Effettua
                  WHERE cliente.id_cliente=Effettua.id_cliente and Prenotazione.id_pren=Effettua.id_pren
                  and (ruolo like 'capo%' or ruolo like 'ospite%'))
           ORDER BY id_lomb";


$result=mysqli_query($con,$select);

if ((empty($result)))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca ".mysqli_error($con));
  exit();
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }
 if ((empty($rows)))
 {
   echo ("Non ci sono prenotazioni da modificare.");
   exit();
 }


echo (" Scegliere la camera da modificare: <br>");

 foreach($rows as $riga)
 {
  $date_arrivo=new DateTime($riga['data_arrivo']);
  $date_partenza=new DateTime($riga['data_partenza']);
  echo (" <br><input type=radio name=id_pren value='$riga[id_pren]'> Prenotazione numero: <b>$riga[id_lomb]</b>
          <br> &emsp; &emsp; &emsp; &emsp; &emsp; Occupata <b>dal ". date_format($date_arrivo,'d/m/Y') ." al ". date_format($date_partenza,'d/m/Y') ."</b>
          da <b>$riga[cognome] $riga[nome] </b>. <br>  ");
 }

}

?>
<br><br><br>
<input type="submit" value="Continua per modificare la prenotazione">
</FORM>
</fieldset>


</BODY>
</HTML>