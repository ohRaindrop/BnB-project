<HTML>
<BODY>
<FONT SIZE=3>

<?php
include "../database2.inc";
$max = new DateTime();
$min = new DateTime();

$select_all= "SELECT DISTINCT prenotazione.*, Cliente.nome as nome_cliente, Cliente.*, relativa.*, camera.*, effettua.*
              FROM Cliente
              INNER JOIN effettua ON cliente.id_cliente=effettua.id_cliente
              INNER JOIN prenotazione ON effettua.id_pren=prenotazione.id_pren
              INNER JOIN relativa ON prenotazione.id_pren=relativa.id_pren
              INNER JOIN camera ON relativa.nome_camera=camera.nome
              WHERE Prenotazione.id_pren=(SELECT prenotazione.id_pren
                                          FROM Cliente
                                          INNER JOIN effettua ON cliente.id_cliente=effettua.id_cliente
                                          INNER JOIN prenotazione ON effettua.id_pren=prenotazione.id_pren
                                          INNER JOIN relativa ON prenotazione.id_pren=relativa.id_pren
                                          INNER JOIN camera ON relativa.nome_camera=camera.nome
                                          WHERE Prenotazione.id_pren='$_POST[id_pren]'
                                          )
             AND relativa.id_pren=effettua.id_pren
              AND Cliente.id_cliente in
                 (SELECT DISTINCT id_cliente
                  FROM Effettua
                  WHERE cliente.id_cliente=Effettua.id_cliente and Prenotazione.id_pren=Effettua.id_pren)
             ";

$result_select_all=mysqli_query($con,$select_all);
$riga=mysqli_fetch_array($result_select_all, MYSQLI_ASSOC);

$data_arrivo=str_replace(" ", "T", $riga['data_arrivo']);
$data_partenza=str_replace(" ", "T", $riga['data_partenza']);

echo("
<h1> Conferma delle prenotazioni </h1>
<FORM ACTION='conferma_prenotazione_non_registrato1.php' METHOD='post'>
<pre>
<fieldset><legend><b>DATI DEL CLIENTE NON ANCORA REGISTRATO</b></legend>

Nome:  <INPUT TYPE=text NAME=nome maxlength=30  required>   Cognome:  <INPUT TYPE=text NAME=cognome maxlength=30  required>   Sesso:  <select name=sesso required>
                                                                                                                                      <option value=Uomo>Uomo</option>
                                                                                                                                      <option value=Donna>Donna</option></select>
Tipo di identificatore*: <select name='tipo_id' required>
                        <option value='Codice fiscale'>Codice fiscale</option>
                        <option value='Partita IVA'>Partita IVA</option>
                        <option value='Altro'>Altro</option>
                        </select> Identificatore*: <INPUT TYPE='text' NAME='identificatore'  title='Inserire una stringa identificativa' required>

Luogo di nascita:  <INPUT TYPE=text NAME=luogo_nascita maxlength=50  required>   Data di nascita:  <INPUT TYPE=date NAME=data_nascita   required><BR>
Ruolo del cliente:  <select name=ruolo  required>
                    <option value='membro del gruppo'> Membro del gruppo </option>
                    <option value='membro della famiglia'> Membro della famiglia </option>
                    </select>
");
if ($riga['ruolo']!="membro della famiglia")
{
  echo (" Indirizzo:  <INPUT TYPE=text NAME=indirizzo maxlength=100 >");
}
else
{
  echo("Indirizzo:  <INPUT TYPE=text NAME=indirizzo maxlength=100 value='$riga[indirizzo]'>");
}
echo ("
Indirizzo email:  <INPUT TYPE=email NAME=mail maxlength=50  pattern=[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{3,}$ title='nel formato user@dominio.it' >   Telefono:  <INPUT TYPE=tel NAME=telefono maxlength=10   title='Non inserire il +39'>

Cittadinanza:  <INPUT TYPE=text NAME=cittadinanza><BR>
Documento di riconoscimento:
          Tipo:  <select name=tipo_doc_ric value='$riga[tipo_doc_ric]' >
                 <option value='carta diidentita'> Carta di identit� </option>
                 <option value=patente> Patente </option>
                 <option value=passaporto> Passaporto </option>
                 </select>   Numero:  <INPUT TYPE=text NAME=numero_doc_ric maxlength=20 required >

          Luogo di rilascio:  <INPUT TYPE=text NAME=luogo_rilascio maxlength=50>   Data di rilascio:  <INPUT TYPE=date NAME=data_rilascio required><BR> <BR>

</fieldset>

<fieldset><legend><b> DATI DELLA PRENOTAZIONE </b></legend>
ID fornito dalla regione Lombardia: <INPUT TYPE=text NAME=id_lomb maxlength=10 required  value='$_POST[id_lomb]'>
Canale di prenotazione:  <INPUT TYPE=text NAME=canale_prenot maxlength=20  required  value='$riga[canale_prenot]'>

Data di arrivo:  <INPUT TYPE='datetime-local' NAME='data_arrivo'  required value='$data_arrivo'>   Data di partenza:  <INPUT TYPE=datetime-local NAME=data_partenza  MIN='$data_arrivo' required value='$data_partenza'>
Eventuale caparra*:  <INPUT TYPE=number NAME=caparra step=0.1 value='$riga[caparra]'> <BR>
</fieldset>

<fieldset><legend><b> DATI DELLA CAMERA </b></legend>
Nome:  <INPUT TYPE=text NAME=nome_camera required value='$riga[nome_camera]'>   Prezzo:  <INPUT TYPE=number NAME=prezzo  step=0.1 required value='$riga[prezzo]'>

</fieldset>
                                  <input type='submit' value='Inserisci'>

</pre>
</FORM>");
?>