<?php

include   "..\database2.inc";


//escape delle stringhe
$nome_esc=mysqli_real_escape_string ($con , "$_POST[nome]");
$cognome_esc=mysqli_real_escape_string ($con , "$_POST[cognome]");
$canale_prenot_esc=mysqli_real_escape_string ($con , "$_POST[canale_prenot]");
$ruolo_esc=mysqli_real_escape_string ($con , "$_POST[ruolo]");
$arrivo_esc=mysqli_real_escape_string ($con , "$_POST[data_arrivo]");
$partenza_esc=mysqli_real_escape_string ($con , "$_POST[data_partenza]");

//creazione di un identificatore provvisorio
$data=(string)$_POST["data_nascita"];
$identificatore= substr("$_POST[nome]", 0,3) . substr("$_POST[cognome]", 0,3) . substr($data,0,4);


//Inserimento nella tabella Cliente
$select_id_cliente= "SELECT id_cliente
                     FROM Cliente
                     WHERE nome='$nome_esc' AND cognome='$cognome_esc' AND data_nascita='$_POST[data_nascita]'";
$result_cliente=mysqli_query($con,$select_id_cliente);
$result=mysqli_num_rows($result_cliente)==1;

if( (!empty($result_cliente)) AND $result )
    {
     echo "Il cliente � gi� stato ospite della struttura.";
    }
else
    {
      echo("Il cliente non risulta essere registrato. Provvedo.");
      $insert_cliente= "INSERT INTO Cliente (nome, cognome, sesso, identificatore, tipo_id, data_nascita, telefono)
                        VALUES ('$nome_esc','$cognome_esc','$_POST[sesso]','$identificatore', 'altro' ,
                                '$_POST[data_nascita]','$_POST[telefono]')";
      $result_cliente=mysqli_query($con, $insert_cliente);

      if ( empty($result_cliente))
         {
         echo("<br>Errore cliente: uno dei dati inseriti � errato. ".mysqli_error($con));
         exit();
         }
    }



//-------------------------------------------------------------------------------------------------------------------------------------------------------
//Inserimento nella tabella Prenotazione
$insert_prenotazione= "INSERT INTO Prenotazione (data_arrivo, data_partenza, caparra)
                       VALUES ('$_POST[data_arrivo]','$_POST[data_partenza]','$_POST[caparra]')";
$result_prenotazione=mysqli_query($con,$insert_prenotazione);
if (!$result_prenotazione)
 {
 echo("<br>Errore prenotazione: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }

//-------------------------------------------------------------------------------------------------------------------------------------------------------
// Aggiornamento della tabella Camera

$update_camera= "UPDATE Camera
                 SET prezzo = '$_POST[prezzo]'
                 WHERE nome='$_POST[nome_camera]'";
$result_camera=mysqli_query($con, $update_camera);
if (!$result_camera)
 {
 echo("<br>Errore camera: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }

//-------------------------------------------------------------------------------------------------------------------------------------------------------
//Inserimento nella tabella Relativa
if($ruolo_esc=="ospite singolo")
{
  $letti=1;
}
else
{
 $letti=$_POST['num_letti'];
}

$insert_relativa= "INSERT INTO Relativa (id_pren, nome_camera, num_persone)
                   VALUES ( (SELECT id_pren FROM Prenotazione ORDER BY id_pren DESC LIMIT 1),
                            '$_POST[nome_camera]','$letti')";
$result_relativa=mysqli_query($con, $insert_relativa);

if (!$result_relativa)
 {
 echo("<br>Errore relativa: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }


//-------------------------------------------------------------------------------------------------------------------------------------------------------
//Inserimento nella tabella Effettua
$insert_effettua= "INSERT INTO Effettua (id_pren, id_cliente,data, canale_prenot, ruolo)
                   VALUES ( (SELECT id_pren FROM Prenotazione ORDER BY id_pren DESC LIMIT 1),
                            (SELECT id_cliente FROM Cliente WHERE nome='$nome_esc' AND cognome='$cognome_esc'
                                                                  AND data_nascita='$_POST[data_nascita]'),
                            now(),'$canale_prenot_esc','$ruolo_esc')";
$result_effettua=mysqli_query($con, $insert_effettua);
if (!$result_effettua)
 {
 echo("<br>Errore effettua: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }


// Verifica della corretta esecuzione delle query
$result_tot=(($result_cliente) AND ($result_effettua) AND ($result_prenotazione) AND ($result_relativa) AND ($result_camera));
if ( $result_tot==True )
{
  echo ("<br><br>Registrazione della prenotazione provvisoria effettuata correttamente.");
}
else
 {
 echo("<br>Errore: uno dei dati inseriti � errato. ".mysqli_error($con));
 exit();
 }


mysqli_close($con);
?>