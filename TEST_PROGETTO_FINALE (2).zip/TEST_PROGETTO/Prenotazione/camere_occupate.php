<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= " SELECT distinct nome_camera, data_arrivo, data_partenza, num_persone
           FROM Relativa 
           INNER JOIN PRENOTAZIONE ON relativa.id_pren=prenotazione.id_pren
           WHERE nome_camera IN
                      (
                      SELECT distinct nome_camera
                      FROM Relativa
          	      INNER JOIN PRENOTAZIONE ON relativa.id_pren=prenotazione.id_pren
                      WHERE (prenotazione.data_arrivo>'$_POST[data_arrivo]'
                             AND prenotazione.data_arrivo<'$_POST[data_partenza]'
                             )
                      OR
                             (
                             prenotazione.data_partenza>'$_POST[data_arrivo]'
                             AND prenotazione.data_partenza<'$_POST[data_partenza]'
                             )
                      OR
                             (
                             prenotazione.data_arrivo<'$_POST[data_arrivo]'
                             AND prenotazione.data_partenza>'$_POST[data_partenza]'
                             )
                      )
            AND YEAR(prenotazione.data_arrivo)=YEAR('$_POST[data_arrivo]')
           ";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ((!$result))
{
  echo("<br>Errore: Non esistono camere. ".mysqli_error($con));
}
elseif (!$riga)
{
  echo("<br>Le camere risultano libere durante il periodo indicato. <BR> ".mysqli_error($con));
}
else
{
  //mostra dei risultati

  echo("<center>Lista delle camere occupate nel periodo indicato:</center>");
  echo("<table>");
  echo("<tr>
      <td> Nome </td>
      <td> Numero di persone </td>
      <td> Check-in </td>
      <td> Check-out </td>
      </tr>");
  while($riga)
      {
        $data_arrivo=new DateTime($riga['data_arrivo']);
        $data_partenza=new DateTime($riga['data_partenza']);

       echo("<tr>
       <td>$riga[nome_camera]</td>
       <td>$riga[num_persone]</td>
       <td>". date_format($data_arrivo,'d/m/Y') ."</td>
       <td>". date_format($data_partenza,'d/m/Y') ."</td>
       </tr>");

       $riga=mysqli_fetch_array($result, MYSQLI_ASSOC);
      }
}

//calcolo della permanenza
$date_a = new DateTime("$_POST[data_arrivo]");
$date_p = new DateTime("$_POST[data_partenza]");
$permanenza=date_diff($date_a,$date_p);

$permanenza=$permanenza->format("%a");


//confronto di validit� delle date
$today = new DateTime();
$diff_today_date_a= date_diff($today,$date_a);

if ($date_a < $today)
{
  echo ("<br>Errore: data di arrivo non valida.");
  echo("<br><a href='inserisci_data_per_prenotazione.php'> Indietro </a>");
  exit();
}
elseif ($date_p<$today)
{
  echo ("<br>Errore: data di partenza non valida.");
  echo("<br><a href='inserisci_data_per_prenotazione.php'> Indietro </a>");
  exit();
}

if($date_p>=$date_a)
{
 echo ("</table><br><br>");
 echo (" <br>
        <form action=inserisci_prenotazione_provvisoria.php method=post>
        Controlla i dati:   <br>
        Data di arrivo: <input type=datetime-local name=data_arrivo value='$_POST[data_arrivo]' readonly> <br>
        Data di partenza: <input type=datetime-local name=data_partenza value='$_POST[data_partenza]' readonly> <br>
        <br>
        Permanenza totale:");
 echo $permanenza;
 echo (" notti.
        <br><br>
        <input type=submit value='Continua la prenotazione provvisoria'>
        </form>"
     );
echo("<a href='inserisci_data_per_prenotazione'> Indietro </a>");
}
else
{
   echo ("</table><br><br>");
 echo (" <br>
        <form action=inserisci_prenotazione_provvisoria.php method=post>
        Controlla i dati: <br>
        Data di arrivo: <input type=datetime-local name=data_arrivo value='$_POST[data_partenza]' readonly> <br>
        Data di partenza: <input type=datetime-local name=data_partenza value='$_POST[data_arrivo]' readonly> <br>
        <br>
        Permanenza totale:");

 echo $permanenza;
 echo (" notti.
        <br><br>
        <input type=submit value='Continua la prenotazione provvisoria'>
        </form>"
     );
  echo("<br><a href='inserisci_data_per_prenotazione.php'> Indietro </a>");
}

mysqli_free_result($result);
mysqli_close($con);
?>