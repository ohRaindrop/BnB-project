<?php
include "database2.inc";


//Creazione della tabella Cliente e controllo della corretta esecuzione dell'istruzione
$create="CREATE TABLE Cliente
(
id_cliente	INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
nome 		TEXT NOT NULL,
cognome		TEXT NOT NULL,
identificatore	VARCHAR(16) UNIQUE,
tipo_id         TEXT NOT NULL,
sesso		VARCHAR(5) NOT NULL,
luogo_nascita	TEXT NOT NULL,
data_nascita	DATE NOT NULL,
indirizzo	TEXT,
mail		VARCHAR(50),
telefono        VARCHAR(10),
cittadinanza	VARCHAR(50),
tipo_doc_ric	VARCHAR(20),
numero_doc_ric	VARCHAR(20),
luogo_rilascio	TEXT,
data_rilascio	DATE,

check(sesso='uomo' OR sesso='donna'),
check(tipo_doc_ric='carta di identita\' ' OR tipo_doc_ric='patente' OR tipo_doc_ric='passaporto' OR tipo_doc_ric='permesso di soggiorno'),
check(tipo_id='codice fiscale' OR tipo_id='partita IVA' OR tipo_id='altro')
)";

$result=mysqli_query($con,$create);
if (!($result))
    echo ("<BR><BR> Errore nella creazione della tabella [Cliente]: ". mysqli_error($con));
else
    echo ("<BR><BR> Tabella [Cliente] creata correttamente");


//-------------------------------------------------------------------------------------------------------------------------
//Creazione della tabella Prenotazione e controllo della corretta esecuzione dell'istruzione
$create="CREATE TABLE Prenotazione
(
id_pren         INT AUTO_INCREMENT PRIMARY KEY,
id_lomb		VARCHAR(10) DEFAULT '000',
data_arrivo	DATETIME,
data_partenza	DATETIME,
caparra		INT,
adulti_matrimoniale  	INT DEFAULT 1,
bimbi_0_3  	        INT DEFAULT 0,
bimbi_3_10  	        INT DEFAULT 0,
ragazzi  	        INT DEFAULT 0,
altri_adulti  	        INT DEFAULT 0,

check(caparra>=0),
check (data_arrivo < data_partenza),
check(adulti_matrimoniale>0),
check(bimbi_0_3>=0),
check(bimbi_3_10>=0),
check(ragazzi>=0),
check(altri_adulti>=0)
)";

// $create="ALTER TABLE Prenotazione ADD FOREIGN KEY (id_pagamento) REFERENCES Pagamento(id_pagamento)";

$result=mysqli_query($con,$create);
if (!($result))
    echo ("<BR><BR> Errore nella creazione della tabella [Prenotazione]: ". mysqli_error($con));
else
    echo ("<BR><BR> Tabella [Prenotazione] creata correttamente");


//-------------------------------------------------------------------------------------------------------------------------
//Creazione della tabella Pagamento e controllo della corretta esecuzione dell'istruzione
$create="CREATE TABLE Pagamento
(
id_pagamento	INT AUTO_INCREMENT,
num_pagamento   INT NOT NULL,
tipo		TEXT,
id_pren		INT,
data		DATE NOT NULL,
caparra		INT DEFAULT 0,
sconto		INT DEFAULT 0,
totale		INT,

check(caparra>=0),
check(sconto>=0),
check(totale>=0),

PRIMARY KEY (id_pagamento,id_pren),
FOREIGN KEY(id_pren) REFERENCES Prenotazione(id_pren) ON UPDATE CASCADE ON DELETE CASCADE
)";

$result=mysqli_query($con,$create);
if (!($result))
    echo ("<BR><BR> Errore nella creazione della tabella [Pagamento]: ". mysqli_error($con));
else
    echo ("<BR><BR> Tabella [Pagamento] creata correttamente");


//------------------------------------------------------------------------------------------------------------------------
//Creazione della tabella Camera e controllo della corretta esecuzione dell'istruzione
$create="CREATE TABLE Camera
(
nome		        VARCHAR(30) NOT NULL PRIMARY KEY,
prezzo		        DOUBLE NOT NULL,
cambio_lenzuola	        DATE,
docum_obbligatori	VARCHAR(20),
angolo_tisane	        VARCHAR(20),
kit_cortesia	        VARCHAR(20),

check(prezzo>0),
check(doc_obbligatori='presenti' OR doc_obbligatori='assenti'),
check(angolo_tisane='fornito' OR angolo_tisane='da rifornire'),
check(kit_cortesia='presente' OR kit_cortesia='da cambiare o da fornire')
)";

$result=mysqli_query($con,$create);
if (!($result))
    echo ("<BR><BR> Errore nella creazione della tabella [Camera]: ". mysqli_error($con));
else
    echo ("<BR><BR> Tabella [Camera] creata correttamente");


//-------------------------------------------------------------------------------------------------------------------------
//Creazione della tabella Relativa e controllo della corretta esecuzione dell'istruzione
$create="CREATE TABLE Relativa
(
id_relativa	INT AUTO_INCREMENT PRIMARY KEY,
id_pren		INT DEFAULT 000,
nome_camera	VARCHAR(50) NOT NULL,
num_persone     INT NOT NULL,

FOREIGN KEY (nome_camera) REFERENCES Camera(nome) ON UPDATE CASCADE,
FOREIGN KEY (id_pren) REFERENCES Prenotazione(id_pren) ON UPDATE CASCADE ON DELETE CASCADE

)";

$result=mysqli_query($con,$create);
if (!($result))
    echo ("<BR><BR> Errore nella creazione della tabella [Relativa]: ". mysqli_error($con));
else
    echo ("<BR><BR> Tabella [Relativa] creata correttamente");


//--------------------------------------------------------------------------------------------------------------------------
//Creazione della tabella Effettua e controllo della corretta esecuzione dell'istruzione
$create="CREATE TABLE Effettua
(
id_effettua	INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
data            DATE,
id_cliente	INT NOT NULL,
id_pren		INT,
canale_prenot	TEXT,
ruolo           VARCHAR(25),

check(ruolo='ospite singolo' OR ruolo='capogruppo' OR ruolo='membro del gruppo' OR ruolo='capofamiglia' OR ruolo='membro della famiglia'),

FOREIGN KEY(id_cliente) REFERENCES Cliente(id_cliente) ON UPDATE CASCADE,
FOREIGN KEY(id_pren) REFERENCES Prenotazione(id_pren) ON UPDATE CASCADE ON DELETE CASCADE
)";

$result=mysqli_query($con,$create);
if (!($result))
    echo ("<BR><BR> Errore nella creazione della tabella [Effettua]: ". mysqli_error($con));
else
    echo ("<BR><BR> Tabella [Effettua] creata correttamente");

// chiusura della connessione
mysqli_close($con);
?>