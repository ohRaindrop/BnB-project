<?php

include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= " SELECT prenotazione.*, effettua.ruolo, relativa.nome_camera,  cliente.nome, cliente.cognome
           FROM prenotazione
           INNER JOIN effettua on prenotazione.id_pren=effettua.id_pren
           INNER JOIN relativa ON prenotazione.id_pren=relativa.id_pren
           INNER JOIN cliente ON cliente.id_cliente=effettua.id_cliente
           WHERE prenotazione.id_lomb='$_POST[numero_prenotazione]'";

$result=mysqli_query($con,$select);

if ((!$result) )
{
  echo("Errore: Non esistono prenotazioni aventi questo numero. ".mysqli_error($con));
}
else
{
 //mostra dei risultati
 while($riga = $result->fetch_array())
 {
   $rows[] = $riga;
 }

$count = mysqli_num_rows($result);
if(($count==0) OR ($_POST['numero_prenotazione']=='000'))
{
  echo (" Errore: non esistono prenotazioni aventi questo numero o si sta cercando una prenotazione non registrata.");
  exit();
}

 foreach($rows as $riga)
 {
  $data_arrivo=new DateTime($riga['data_arrivo']);
  $data_partenza=new DateTime($riga['data_partenza']);
  $permanenza=date_diff($data_arrivo,$data_partenza);
  $permanenza=$permanenza->format("%a");


    if ($count>=1)
    {
    echo (" Prenotazione numero: $riga[id_lomb] <br>
            Prevista dal ".date_format($data_arrivo,'d/m/Y')." al ".date_format($data_partenza,'d/m/Y')." - $permanenza giorni. <br>
            All'interno della camera: $riga[nome_camera]<br><br>
         ");
    $count=0;
    }
    if (($riga['ruolo']=="membro del gruppo") OR ($riga['ruolo']=="membro della famiglia"))
    {
      echo ("
            E di $riga[cognome] $riga[nome] ($riga[ruolo])<br>
            ");
    }
    else
    {
      echo ("
            A nome di $riga[cognome] $riga[nome] ($riga[ruolo])<br>
            ");
    }

 }
}

$select=" SELECT pagamento.*, cliente.nome, cliente.cognome
          FROM pagamento
          INNER JOIN effettua ON effettua.id_pren=pagamento.id_pren
          INNER JOIN cliente  ON effettua.id_cliente=cliente.id_cliente
          WHERE pagamento.id_lomb='$_POST[numero_prenotazione]'
          ";

$ris=mysqli_query($con,$select);
$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if((!$ris) OR (!$riga))
{
  echo("La prenotazione non � ancora stata pagata ".mysqli_error($con));
  exit();
}

echo ("<br><br> I dati del pagamento relativo la prenotazione scelta sono i seguenti:");
while($riga)
{
  $data=new DateTime($riga['data']);

  echo (" <br> Pagamento numero: $riga[num_pagamento], effettuato tramite $riga[tipo] il ".date_format($data,'d/m/Y')."
          <br> Presenta:
          <br> Importo: $riga[totale]
          <br> Sconto: $riga[sconto]
          <br> Caparra: $riga[caparra]
         ");
  $riga=mysqli_fetch_array($ris,MYSQLI_ASSOC);
}



mysqli_free_result($ris);
mysqli_free_result($result);
mysqli_close($con);

?>