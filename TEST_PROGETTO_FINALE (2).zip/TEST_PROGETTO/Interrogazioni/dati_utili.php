<?php
include   "..\database2.inc";

echo ("<fieldset> <legend> <b>LISTA DEI FATTURATI</b></legend>");
include "fatturato_totale_attivita.php";
echo("<br>");
include "fatturato_totale_anno.php";
echo("<br>");
include "fatturato_totale_mese.php";
echo("<br><br>");
echo ("</fieldset>");

echo("<br>");

echo ("<fieldset> <legend> <b>DATI DEI CLIENTI </b></legend>");
include "clienti_totali.php";
echo("<br>");
include "clienti_totali_anno.php";
echo("<br>");
include "clienti_totali_mese.php";
echo("<br><br>");
echo ("</fieldset>");


mysqli_close($con);
?>
