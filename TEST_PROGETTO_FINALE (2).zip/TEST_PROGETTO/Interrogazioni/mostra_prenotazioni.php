<head>
<style type="text/css">
	.TFtable{
		width:100%;
		border-collapse:collapse;
	}
	.TFtable td{
		padding:7px; border:#4e95f4 1px solid;
	}

</style>
</head>
<body>
<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select = "SELECT DISTINCT Cliente.id_cliente, nome, cognome, data_nascita, telefono,  
                           Prenotazione.id_pren , id_lomb, data_arrivo, data_partenza,
                           nome_camera, ruolo, canale_prenot
           FROM Cliente
           INNER JOIN Effettua ON effettua.id_cliente=cliente.id_cliente
           INNER JOIN Prenotazione ON prenotazione.id_pren=effettua.id_pren
           INNER JOIN Relativa ON prenotazione.id_pren=relativa.id_pren 
           AND effettua.id_pren=relativa.id_pren
           ORDER BY prenotazione.data_arrivo, id_lomb";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ((!$result) OR (!$riga))
{
  echo("<br>Errore: Nessun elemento soddisfa i criteri di ricerca. ".mysqli_error($con));
}


//mostra dei risultati
echo("<center><h1>Lista dei dati delle prenotazioni:</h1></center>
      <br> in blu i capi e in rosa i membri.");

echo("<table class='TFtable'>");

 echo("<tr>
      <td> Nome </td> <td> Cognome </td> <td> Data di nascita </td> <td> Telefono </td> <td> Ruolo </td>
      <td> Canale di prenotazione </td> <td> Data di arrivo </td> <td> Data di partenza </td> <td> Camera </td>
      </tr>");
while($riga)
{
  $date_arrivo=new DateTime($riga['data_arrivo']);
  $date_partenza=new DateTime($riga['data_partenza']);
  $data_nascita=new DateTime($riga['data_nascita']);
  if(($riga['ruolo']=='ospite singolo') OR ($riga['ruolo']=='capo famiglia') OR ($riga['ruolo']=='capo gruppo')OR($riga['ruolo']=='capofamiglia') OR ($riga['ruolo']=='capogruppo'))
  {
   echo("<tr bgcolor='#e6fff2'>
       <td>$riga[nome]</td>
       <td>$riga[cognome]</td>
         <td>".date_format($data_nascita,'d/m/Y')."</td>
       <td>$riga[telefono]</td>
       <td>$riga[ruolo]</td>
       <td>$riga[canale_prenot]</td>
       <td>". date_format($date_arrivo,'d/m/Y') ."</td>
       <td>". date_format($date_partenza,'d/m/Y') ."</td>
       <td>$riga[nome_camera]</td>
       </tr>
       ");
  }
  else
  {
    echo("<tr bgcolor='#ffe6ff'>
       <td>$riga[nome]</td>
       <td>$riga[cognome]</td>
       <td>$riga[data_nascita]</td>
       <td>$riga[telefono]</td>
       <td>$riga[ruolo]</td>
       </tr>
       ");
  }

  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}

echo("</table>");

mysqli_free_result($result);
mysqli_close($con);
?>