<html>
<head>
<link href="myTab.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= "SELECT * FROM Cliente";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ( (!$result) OR (!$riga) )
{
  echo("<br>Errore: nessun cliente trovato. ".mysqli_error($con));
  exit();
}

//escape
$tipo_doc_ric_esc=mysqli_real_escape_string ($con , "$riga[tipo_doc_ric]" );

//mostra dei risultati

echo("<center><h1>Lista dei clienti:</h1></center>");

echo("<table class='myTab'>");


 echo("<tr>
      <td> Id </td>
      <td> Nome </td> <td> Cognome </td>
      <td> Identificatore </td> <td> Tipo di identificatore </td>
      <td> Sesso </td>
      <td> Luogo di nascita </td> <td> Data di nascita </td>
      <td> Indirizzo </td> <td> Mail </td> <td> Telefono </td>
      <td>Cittadinanza </td>
      <td> Documento di riconoscimento </td> <td> Numero del documento </td>
      <td> Luogo di rilascio </td> <td> Data di rilascio </td>
      </tr>");
while($riga)
{
  echo("<tr>
       <td>$riga[id_cliente]</td>
       <td>$riga[nome]</td>
       <td>$riga[cognome]</td>
       <td>$riga[identificatore]</td>         
       <td>$riga[tipo_id]</td>
       <td>$riga[sesso]</td>
       <td>$riga[luogo_nascita]</td>
       <td>$riga[data_nascita]</td>
       <td>$riga[indirizzo]</td>
       <td>$riga[mail]</td>
       <td>$riga[telefono]</td>
       <td>$riga[cittadinanza]</td>
       <td>$riga[tipo_doc_ric]</td>
       <td>$riga[numero_doc_ric]</td>
       <td>$riga[luogo_rilascio]</td>
       <td>$riga[data_rilascio]</td>
       </tr>");

  $riga=mysqli_fetch_array($result, MYSQLI_ASSOC);
}

echo("</table>");

mysqli_free_result($result);
mysqli_close($con);
?>