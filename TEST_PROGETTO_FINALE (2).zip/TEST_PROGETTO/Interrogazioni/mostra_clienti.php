<html>
<head>
<link href="myTab.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= "SELECT nome,cognome,sesso,luogo_nascita,data_nascita,indirizzo, telefono, identificatore, tipo_id, mail FROM Cliente";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ( (!$result) OR (!$riga) )
{
  echo("<br>Errore: nessun cliente trovato. ".mysqli_error($con));
  exit();
}


//mostra dei risultati
echo("<center><h1>Lista dei clienti:</h1></center>");

echo("<table class='myTab'>");

 echo("<tr>
      <td> Nome </td> <td> Cognome </td> <td> Sesso </td> <td> Identificatore </td> <td> Tipo di identificatore </td>
      <td> Luogo di nascita </td> <td> Data di nascita </td>
      <td> Indirizzo </td> <td> Telefono </td> <td> E-mail </td>
      </tr><br>");
while($riga)
{
  $data_nascita=new DateTime($riga['data_nascita']);

  echo(" <tr>
         <td>$riga[nome]</td>
         <td>$riga[cognome]</td>
         <td>$riga[sesso]</td>
         <td>$riga[identificatore]</td>
         <td>$riga[tipo_id]</td>
         <td>$riga[luogo_nascita]</td>
         <td>".date_format($data_nascita,'d/m/Y')."</td>
         <td>$riga[indirizzo]</td>
         <td>$riga[telefono]</td>
         <td>$riga[mail]</td>
         </tr>");
  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}

echo("</table>");

mysqli_free_result($result);
mysqli_close($con);
?>
