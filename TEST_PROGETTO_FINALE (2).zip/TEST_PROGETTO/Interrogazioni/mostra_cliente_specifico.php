<?php
include "../database2.inc";

$select=" SELECT cliente.*
          FROM cliente
          WHERE nome='$_POST[nome_cliente]'
          AND cognome='$_POST[cognome_cliente]'
          ";

$ris=mysqli_query($con,$select);
$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if((!$ris) OR (!$riga))
{
  echo("Errore: il cliente non esiste o si e' sbagliato a digitare. ".mysqli_error($con));
  exit();
}

echo ("I dati del cliente sono i seguenti:");
while($riga)
{
  $data_nascita=new DateTime($riga['data_nascita']);

  echo (" <br> Nome e Cognome: $riga[nome] $riga[cognome] ($riga[sesso])
         <br> Identificato da: $riga[tipo_id] , numero: $riga[identificatore]
         <br> Nato a: $riga[luogo_nascita] il: ".date_format($data_nascita,'d/m/Y')."
         <br> Indirizzo: $riga[indirizzo]
         <br> Telefono: $riga[telefono]
         <br> Mail: $riga[mail]
         ");
  $riga=mysqli_fetch_array($ris,MYSQLI_ASSOC);
}

$select=" SELECT cliente.* , prenotazione.data_arrivo, prenotazione.data_partenza, ruolo, prenotazione.id_lomb
          FROM cliente
          INNER JOIN effettua ON cliente.id_cliente=effettua.id_cliente
          INNER JOIN prenotazione ON effettua.id_pren=prenotazione.id_pren
          WHERE nome='$_POST[nome_cliente]'
          AND cognome='$_POST[cognome_cliente]'
          ";

$ris=mysqli_query($con,$select);
$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if((!$ris) OR (!$riga))
{
  echo("<br>Errore: il cliente non esiste o si � sbagliato a digitare. ".mysqli_error($con));
  exit();
}

echo ("<br><br>Ed ha soggiornato da noi:");
while($riga)
{
  $data_arrivo=new DateTime($riga['data_arrivo']);
  $data_partenza=new DateTime($riga['data_partenza']);

  echo ("<br><li> Dal ".date_format($data_arrivo,'d/m/Y')." al ".date_format($data_partenza,'d/m/Y')."
         <br> Nel ruolo di: $riga[ruolo].
         <br> Sotto la prenotazione numero: $riga[id_lomb]");
  if ($riga['id_lomb']=='000')
     {
       echo(" (La prenotazione e' da confermare)");
     }
  echo ("<br>");
  $riga=mysqli_fetch_array($ris,MYSQLI_ASSOC);
}


mysqli_free_result($ris);
mysqli_close($con);
?>