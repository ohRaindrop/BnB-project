<?php
include   "..\database2.inc";

$select_totale= "SELECT COUNT(cliente.id_cliente) AS clienti_tot, MONTH(CURRENT_DATE) AS mese
                 FROM cliente,prenotazione,effettua
                 where effettua.id_pren=prenotazione.id_pren
                and effettua.id_cliente=cliente.id_cliente
                AND MONTH(prenotazione.data_arrivo)=MONTH(CURRENT_DATE)
                AND cittadinanza!=''";

$select_totale_ita="SELECT COUNT(cliente.id_cliente) AS clienti_ita
                 FROM cliente,prenotazione,effettua
                 WHERE effettua.id_pren=prenotazione.id_pren
                 AND effettua.id_cliente=cliente.id_cliente
                 AND MONTH(prenotazione.data_arrivo)=MONTH(CURRENT_DATE)
                 AND cittadinanza LIKE '_ta%'";

$select_totale_non_ita="SELECT COUNT(cliente.id_cliente) AS clienti_non_ita
                 FROM cliente,prenotazione,effettua
                 WHERE effettua.id_pren=prenotazione.id_pren
                AND effettua.id_cliente=cliente.id_cliente
                AND MONTH(prenotazione.data_arrivo)=MONTH(CURRENT_DATE)
                AND NOT  cittadinanza like '_ta%' OR cittadinanza=''";


$result_tot=mysqli_query($con,$select_totale);
$riga_tot=mysqli_fetch_array($result_tot,MYSQLI_ASSOC);

$result_ita=mysqli_query($con,$select_totale_ita);
$riga_ita=mysqli_fetch_array($result_ita,MYSQLI_ASSOC);

$result_non_ita=mysqli_query($con,$select_totale_non_ita);
$riga_non_ita=mysqli_fetch_array($result_non_ita,MYSQLI_ASSOC);



if ( (!$result) OR (!$riga_tot) OR (!$riga_ita) OR (!$riga_non_ita) )
{
  echo("<br>Errore: nessun cliente trovato. ".mysqli_error($con));
  exit();
}


//mostra dei risultati
echo ("<br> <li> Clienti ospitati nell'arco di questo mese ");
while($riga_tot and ($riga_ita or $riga_non_ita))
{
  switch($riga_tot['mese'])
 {
  case 1:
   echo("(Gennaio): ");
   break;

  case 2:
   echo("(Febbraio): ");
   break;

  case 3:
   echo("(Marzo): ");
   break;

  case 4:
   echo("(Aprile): ");
   break;

  case 5:
   echo("(Maggio): ");
   break;

  case 6:
   echo("(Giugno): ");
   break;

  case 7:
   echo("(Luglio): ");
   break;

  case 8:
   echo("(Agosto): ");
   break;

  case 9:
   echo("(Settembre): ");
   break;

  case 10:
   echo("(Ottobre): ");
   break;

  case 11:
   echo("(Novembre): ");
   break;

  case 12:
   echo("(Dicembre): ");
   break;

  default:
  echo("errore.");
  break;
 }
  echo ("$riga_tot[clienti_tot]");
  echo (", di cui:   ");
  echo ("$riga_ita[clienti_ita] italiani e ");
  echo ("$riga_non_ita[clienti_non_ita] non italiani");

  $riga_non_ita=mysqli_fetch_array($result_non_ita,MYSQLI_ASSOC);
  $riga_ita=mysqli_fetch_array($result_ita,MYSQLI_ASSOC);
  $riga_tot=mysqli_fetch_array($result_tot,MYSQLI_ASSOC);
}


mysqli_free_result($result_tot);
mysqli_free_result($result_ita);
mysqli_free_result($result_non_ita);

?>
