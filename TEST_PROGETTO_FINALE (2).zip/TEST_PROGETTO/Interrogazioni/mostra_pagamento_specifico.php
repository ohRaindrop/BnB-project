<?php

include "../database2.inc";

$select=" SELECT pagamento.*, prenotazione.id_lomb, cliente.nome, cliente.cognome
          FROM pagamento
          INNER JOIN prenotazione ON pagamento.id_pren=prenotazione.id_pren
          INNER JOIN effettua ON effettua.id_pren=pagamento.id_pren
          INNER JOIN cliente  ON effettua.id_cliente=cliente.id_cliente
          WHERE pagamento.num_pagamento='$_POST[numero_pagamento]'
          ";

$ris=mysqli_query($con,$select);
$riga=mysqli_fetch_array($ris, MYSQLI_ASSOC);

if((!$ris) OR (!$riga))
{
  echo("Errore: il pagamento non esiste o si e' sbagliato a digitare. ".mysqli_error($con));
  exit();
}

echo ("I dati del pagamento sono i seguenti:");
while($riga)
{
  $data=new DateTime($riga['data']);

  echo (" <br> Pagamento numero: $riga[num_pagamento], relativo alla prenotazione $riga[id_lomb]
          <br> Effettuato da: $riga[nome] $riga[cognome] tramite $riga[tipo] il ".date_format($data,'d/m/Y')."
          <br> Presenta:
          <br> Importo: $riga[totale]
          <br> Sconto: $riga[sconto]
          <br> Caparra: $riga[caparra]
         ");
  $riga=mysqli_fetch_array($ris,MYSQLI_ASSOC);
}



mysqli_free_result($ris);
mysqli_close($con);

?>