<html>
<head>
<link href="myTab.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select= "SELECT prenotazione.id_pren,  prenotazione.id_lomb, totale, num_pagamento, cliente.nome, cliente.cognome, pagamento.data as data_pag
          FROM prenotazione 
          INNER JOIN effettua on effettua.id_pren=prenotazione.id_pren
          INNER JOIN pagamento ON prenotazione.id_pren=pagamento.id_pren
          INNER JOIN cliente ON effettua.id_cliente=cliente.id_cliente
          WHERE NOT (ruolo LIKE 'membro%')
          ORDER BY data_pag DESC";

$result=mysqli_query($con,$select);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ( (!$result) OR (!$riga) )
{
  echo("<br>Errore: nessun pagamento trovato. ".mysqli_error($con));
  exit();
}


//mostra dei risultati
echo("<center><h1>Lista dei pagamenti ricevuti:</h1></center>");

echo("<table class='myTab'>");

 echo("<tr>
      <td> Nome </td> <td> Cognome </td> 
      <td> ID della prenotazione </td> <td> Numero del pagamento </td> <td> Data del pagamento </td> <td> Totale del pagamento </td>
      </tr><br>");
while($riga)
{
  $data=new DateTime($riga['data_pag']);

  echo(" <tr>
         <td>$riga[nome]</td>
         <td>$riga[cognome]</td>
         <td>$riga[id_lomb]</td>
         <td>$riga[num_pagamento]</td>
         <td>".date_format($data,'d/m/Y')."</td>
         <td>$riga[totale]</td>
         </tr>");
  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}

echo("</table>");

mysqli_free_result($result);
mysqli_close($con);
?>
