<HTML>

<HEAD>
</HEAD>

<BODY>
<FONT SIZE=3>

<h3>Inserisci ci� che vuoi cercare:</h3>

<FORM ACTION="mostra_cliente_specifico.php" METHOD="post">
<pre>
<fieldset> <legend> <b> CERCA DATI DI UN CLIENTE SPECIFICO </b> </legend>
Cerca i dati e le prenotazioni a nome di un cliente; inserisci:
<br>
<input type="search" name="nome_cliente" placeholder="Nome">    <input type="search" name="cognome_cliente" placeholder="Cognome"> <input type="submit" name="Cerca">
<br><br>
</fieldset>
</FORM>

<FORM ACTION="mostra_prenotazione_specifica.php" METHOD="post">
<fieldset> <legend> <b> CERCA DATI DI UNA PRENOTAZIONE SPECIFICA </b> </legend>
Cerca i dati di una prenotazione; inserisci:
<br>
<input type="search" name="numero_prenotazione" placeholder="Idetificativo della prenotazione">   <input type="submit" name="Cerca">
<br><br>
</fieldset>
</FORM>

<FORM ACTION="mostra_pagamento_specifico.php" METHOD="post">
<fieldset> <legend> <b> CERCA DATI DI UN PAGAMENTO SPECIFICO </b> </legend>
Cerca i dati di un pagamento; inserisci:
<br>
<input type="search" name="numero_pagamento" placeholder="Numero del pagamento">   <input type="submit" name="Cerca">
<br><br>
</fieldset>
</FORM>

</pre>

</BODY>
</HTML>