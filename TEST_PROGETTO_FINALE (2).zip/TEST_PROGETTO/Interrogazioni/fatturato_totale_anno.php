<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select_totale_anno= "SELECT SUM(totale) AS totale_anno, YEAR(CURRENT_DATE) as anno
                 FROM pagamento
                 WHERE   YEAR(data) = YEAR(CURRENT_DATE())";

$result=mysqli_query($con,$select_totale_anno);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ( (!$result) OR (!$riga) )
{
  echo("<br>Errore: nessun pagamento trovato in questo anno. ".mysqli_error($con));
  exit();
}


//mostra dei risultati
echo ("<br> <li> Fatturato totale dall'inizio dell'anno ");
while($riga)
{
  echo("$riga[anno]: ");
  echo("$riga[totale_anno]");
  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}


mysqli_free_result($result);

?>           