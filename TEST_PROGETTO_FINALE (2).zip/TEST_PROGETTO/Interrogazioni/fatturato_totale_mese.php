<?php
include   "..\database2.inc";

//operazione generale su DB e verifica di successo
$select_totale_mese= "SELECT SUM(totale) AS totale_mese, MONTH(CURRENT_DATE) as mese
                 FROM pagamento
                 WHERE MONTH(data) = MONTH(CURRENT_DATE())
                 AND YEAR(data) = YEAR(CURRENT_DATE())";

$result=mysqli_query($con,$select_totale_mese);
$riga=mysqli_fetch_array($result,MYSQLI_ASSOC);

if ( (!$result) OR (!$riga) )
{
  echo("<br>Errore: nessun pagamento trovato per questo mese. ".mysqli_error($con));
  exit();
}


//mostra dei risultati
echo ("<br> <li> Fatturato di questo mese  ");
while($riga)
{
  switch($riga['mese'])
 {
  case 1:
   echo("(Gennaio) :");
   break;
  
  case 2:
   echo("(Febbraio) :");
   break;

  case 3:
   echo("(Marzo) :");
   break;

  case 4:
   echo("(Aprile) :");
   break;

  case 5:
   echo("(Maggio) :");
   break;

  case 6:
   echo("(Giugno) :");
   break;

  case 7:
   echo("(Luglio) :");
   break;

  case 8:
   echo("(Agosto) :");
   break;

  case 9:
   echo("(Settembre) :");
   break;

  case 10:
   echo("(Ottobre) :");
   break;

  case 11:
   echo("(Novembre) :");
   break;

  case 12:
   echo("(Dicembre) :");
   break;

  default:
  echo("errore.");
  break;
 }
  echo("$riga[totale_mese]");
  $riga=mysqli_fetch_array($result,MYSQLI_ASSOC);
}


mysqli_free_result($result);

?>
